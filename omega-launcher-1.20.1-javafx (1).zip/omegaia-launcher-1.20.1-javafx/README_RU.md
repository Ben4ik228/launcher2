# OmegaIA Launcher (JDK 17 · JavaFX 17 · Minecraft 1.20.1)

Готовый проект десктопного лаунчера для сервера **OmegaIA** (1.20.1, Forge 47.3.0).

## Быстрая компиляция в 1 клик (Windows)
1. Установите **JDK 17** (например, Eclipse Temurin 17 LTS).
2. Дважды нажмите на start.bat — скрипт сам найдёт JDK 17, при необходимости скачает портативный Maven, соберёт target/omega-launcher-2.4.0.jar (со встроенным JavaFX 17) и создаст автономный dist/OmegaLauncher/OmegaLauncher.exe (со встроенной Java со всеми модулями для запуска Minecraft 1.20.1 Forge).

## Автоматическая установка клиента 1.20.1 Forge + OptiFine
1. **Сам клиент 1.20.1 + Forge 47.3.0 скачивать на GitHub не нужно**: при первом нажатии «Играть» `ClientInstallerService.java` сам скачает официальные файлы Minecraft 1.20.1 (клиент, библиотеки, нативы, ресурсы) с серверов Mojang и установит Forge 47.3.0 в headless-режиме.
2. **OptiFine 1.20.1**: просто добавьте `OptiFine_1.20.1_HD_U_I6.jar` в ваш архив модов `.zip` или `manifest.json` — Forge загрузит его автоматически из папки `mods/`.
3. **options.txt и optionsof.txt**: укажите прямые ссылки (включая обычные GitHub `/blob/...` ссылки — они автоматически конвертируются в `raw.githubusercontent.com`) в настройках лаунчера или внутри `manifest.json`.

## Античит и проверка целостности
- `IntegrityVerifier.java` проверяет SHA-256 собственного JAR-файла лаунчера.
- Перед запуском `mods/` сканируется: любые сторонние `.jar` отправляются в `quarantine/`.
- Во время работы игры `WatchService` в `MinecraftLauncher.java` следит за `mods/` и при попытке подкинуть чит-мод мгновенно завершает процесс.
