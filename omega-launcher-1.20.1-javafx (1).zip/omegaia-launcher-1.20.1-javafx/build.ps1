﻿$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  OmegaIA Launcher 1.20.1 - Компиляция на JDK 17" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

function Find-Jdk17 {
    $candidates = @()
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME "bin\javac.exe"))) {
        $candidates += $env:JAVA_HOME
    }
    $javacCmd = Get-Command javac.exe -ErrorAction SilentlyContinue
    if ($javacCmd -and $javacCmd.Source -and ($javacCmd.Source -notmatch "javapath")) {
        $candidates += (Split-Path (Split-Path $javacCmd.Source -Parent) -Parent)
    }
    $roots = @(
        "$env:ProgramFiles\Eclipse Adoptium",
        "$env:ProgramFiles\Java",
        "$env:ProgramFiles\Microsoft",
        "$env:ProgramFiles\BellSoft",
        "$env:ProgramFiles\Amazon Corretto",
        "$env:ProgramFiles\Zulu",
        "$env:ProgramFiles\Semeru",
        "$env:LOCALAPPDATA\Programs\Eclipse Adoptium"
    )
    foreach ($root in $roots) {
        if (Test-Path $root) {
            Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | ForEach-Object {
                if (Test-Path (Join-Path $_.FullName "bin\javac.exe")) {
                    $candidates += $_.FullName
                }
            }
        }
    }
    foreach ($dir in ($candidates | Select-Object -Unique)) {
        $javac = Join-Path $dir "bin\javac.exe"
        if (Test-Path $javac) {
            try {
                $ver = & $javac -version 2>&1 | Out-String
                if ($ver -match "javac\s+(17|18|19|20|21|22|23)\.") {
                    return $dir
                }
            } catch {}
        }
    }
    return $null
}

$JdkHome = Find-Jdk17
if (-not $JdkHome) {
    Write-Host "[ОШИБКА] JDK 17 не найден на этом компьютере!" -ForegroundColor Red
    Write-Host "Скачайте и установите Eclipse Temurin JDK 17:" -ForegroundColor Yellow
    Write-Host "https://adoptium.net/temurin/releases/?version=17"
    exit 1
}

$env:JAVA_HOME = $JdkHome
$env:PATH = (Join-Path $JdkHome "bin") + ";" + $env:PATH
Write-Host "[OK] Используется JDK: $JdkHome" -ForegroundColor Green
& (Join-Path $JdkHome "bin\java.exe") -version
Write-Host ""

$MvnCmd = $null
$mvnInPath = Get-Command mvn -ErrorAction SilentlyContinue
if ($mvnInPath) {
    $MvnCmd = $mvnInPath.Source
} else {
    $localMvn = Join-Path $ProjectRoot ".tools\apache-maven-3.9.9\bin\mvn.cmd"
    if (-not (Test-Path $localMvn)) {
        Write-Host "[INFO] Maven не установлен. Скачиваю портативный Apache Maven 3.9.9..." -ForegroundColor Yellow
        $toolsDir = Join-Path $ProjectRoot ".tools"
        New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null
        $mavenZip = Join-Path $toolsDir "maven.zip"
        Invoke-WebRequest -Uri "https://archive.apache.org/dist/maven/maven-3/3.9.9/binaries/apache-maven-3.9.9-bin.zip" -OutFile $mavenZip
        Expand-Archive -Path $mavenZip -DestinationPath $toolsDir -Force
        Remove-Item $mavenZip -Force -ErrorAction SilentlyContinue
    }
    $MvnCmd = $localMvn
}

if (-not (Test-Path $MvnCmd)) {
    Write-Host "[ОШИБКА] Не удалось подготовить Maven." -ForegroundColor Red
    exit 1
}

Write-Host "[OK] Сборка универсального JAR (с JavaFX 17 внутри)..." -ForegroundColor Green
& $MvnCmd clean package -DskipTests
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ОШИБКА] Компиляция завершилась с ошибкой!" -ForegroundColor Red
    exit 1
}

$ShadedJar = Join-Path $ProjectRoot "target\omega-launcher-2.4.0.jar"
Write-Host ""
Write-Host "[OK] JAR успешно собран: $ShadedJar" -ForegroundColor Green
Write-Host "     Он уже содержит JavaFX 17 и запускается на обычной Java 17+."

$jpackageExe = Join-Path $JdkHome "bin\jpackage.exe"
$ExePath = Join-Path $ProjectRoot "dist\OmegaLauncher\OmegaLauncher.exe"
if (Test-Path $jpackageExe) {
    Write-Host ""
    Write-Host "[INFO] Собираю автономный OmegaLauncher.exe (как TLauncher, без установки Java)..." -ForegroundColor Yellow
    $DistDir = Join-Path $ProjectRoot "dist"
    if (Test-Path $DistDir) { Remove-Item $DistDir -Recurse -Force }
    $AsciiStage = Join-Path $env:PUBLIC "OmegaLauncherBuild"
    $StageInput = Join-Path $AsciiStage "input"
    $StageOut = Join-Path $AsciiStage "out"
    $StageRuntime = Join-Path $AsciiStage "runtime"
    $jlinkExe = Join-Path $JdkHome "bin\jlink.exe"
    $modulesList = "java.se,jdk.charsets,jdk.crypto.cryptoki,jdk.crypto.ec,jdk.dynalink,jdk.jfr,jdk.localedata,jdk.management,jdk.management.agent,jdk.naming.dns,jdk.naming.rmi,jdk.net,jdk.unsupported,jdk.zipfs"
    if (Test-Path $AsciiStage) { Remove-Item $AsciiStage -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $StageInput, $StageOut | Out-Null
    Copy-Item $ShadedJar -Destination $StageInput -Force
    try {
        & $jlinkExe `
            --add-modules $modulesList `
            --no-header-files `
            --no-man-pages `
            --compress=2 `
            --output $StageRuntime
        & $jpackageExe `
            --type app-image `
            --name "OmegaLauncher" `
            --app-version "2.4.0" `
            --input $StageInput `
            --main-jar "omega-launcher-2.4.0.jar" `
            --main-class "com.omegacraft.launcher.Main" `
            --runtime-image $StageRuntime `
            --dest $StageOut
        $OutExe = Join-Path $StageOut "OmegaLauncher\OmegaLauncher.exe"
        if (Test-Path $OutExe) {
            $OutRuntimeBin = Join-Path $StageOut "OmegaLauncher\runtime\bin"
            if (-not (Test-Path (Join-Path $OutRuntimeBin "java.exe"))) {
                Copy-Item (Join-Path $StageRuntime "bin\java.exe") -Destination $OutRuntimeBin -Force -ErrorAction SilentlyContinue
            }
            if (-not (Test-Path (Join-Path $OutRuntimeBin "javaw.exe"))) {
                Copy-Item (Join-Path $StageRuntime "bin\javaw.exe") -Destination $OutRuntimeBin -Force -ErrorAction SilentlyContinue
            }
            New-Item -ItemType Directory -Force -Path $DistDir | Out-Null
            Copy-Item (Join-Path $StageOut "OmegaLauncher") -Destination $DistDir -Recurse -Force
            Write-Host "[OK] Готово! Автономный лаунчер создан: $ExePath" -ForegroundColor Green
            Write-Host "     Папку dist\OmegaLauncher можно заархивировать и раздавать игрокам!"
        }
    } catch {
        Write-Host "[INFO] jpackage пропущен, используйте собранный JAR: $ShadedJar" -ForegroundColor Yellow
    } finally {
        if (Test-Path $AsciiStage) { Remove-Item $AsciiStage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

Write-Host ""
$ans = Read-Host "Запустить лаунчер прямо сейчас? (y/n)"
if ($ans -eq "y" -or $ans -eq "Y" -or $ans -eq "д" -or $ans -eq "Д") {
    if (Test-Path $ExePath) {
        Start-Process -FilePath $ExePath
    } else {
        Start-Process -FilePath (Join-Path $JdkHome "bin\javaw.exe") -ArgumentList "-jar", "`"$ShadedJar`""
    }
}
Write-Host "Готово!" -ForegroundColor Green
