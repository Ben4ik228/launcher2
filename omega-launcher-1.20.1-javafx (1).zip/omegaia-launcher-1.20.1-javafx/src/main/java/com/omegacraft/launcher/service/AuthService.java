package com.omegacraft.launcher.service;

import com.google.gson.Gson;
import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.SessionData;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

/**
 * Тестовая авторизация по паролю с шифрованным сохранением сессии (AES-256-GCM).
 */
public class AuthService {
    private static final int GCM_TAG_BITS = 128;
    private static final int IV_LENGTH = 12;
    private final Path sessionFile;
    private final LauncherConfig config;
    private final Gson gson = new Gson();

    public AuthService(Path gameDirectory, LauncherConfig config) {
        this.sessionFile = gameDirectory.resolve("session.dat");
        this.config = config;
    }

    public AuthResult login(String username, String password, boolean rememberSession) {
        if (username == null || username.trim().length() < 3) {
            return AuthResult.failure("Никнейм должен содержать минимум 3 символа.");
        }
        if (password == null || !password.equals(config.getTestPassword())) {
            return AuthResult.failure("Неверный пароль. Тестовый пароль: " + config.getTestPassword());
        }

        String cleanName = username.trim();
        String offlineUuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + cleanName).getBytes(StandardCharsets.UTF_8)).toString();
        String token = UUID.randomUUID().toString().replace("-", "");
        long ttlMs = rememberSession ? 7L * 24 * 60 * 60 * 1000 : 2L * 60 * 60 * 1000;
        SessionData session = new SessionData(cleanName, offlineUuid, token, System.currentTimeMillis() + ttlMs);

        if (rememberSession) {
            saveEncryptedSession(session);
        } else {
            logout();
        }
        return AuthResult.success(session);
    }

    public Optional<SessionData> restoreSession() {
        if (!Files.exists(sessionFile)) {
            return Optional.empty();
        }
        try {
            byte[] payload = Files.readAllBytes(sessionFile);
            if (payload.length <= IV_LENGTH) return Optional.empty();

            byte[] iv = Arrays.copyOfRange(payload, 0, IV_LENGTH);
            byte[] cipherText = Arrays.copyOfRange(payload, IV_LENGTH, payload.length);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, deriveMachineKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
            String json = new String(cipher.doFinal(cipherText), StandardCharsets.UTF_8);

            SessionData session = gson.fromJson(json, SessionData.class);
            if (session != null && session.isValid()) {
                return Optional.of(session);
            }
            logout();
        } catch (Exception ignored) {
            logout();
        }
        return Optional.empty();
    }

    public void logout() {
        try {
            Files.deleteIfExists(sessionFile);
        } catch (Exception ignored) {
        }
    }

    private void saveEncryptedSession(SessionData session) {
        try {
            Files.createDirectories(sessionFile.getParent());
            byte[] iv = new byte[IV_LENGTH];
            new SecureRandom().nextBytes(iv);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, deriveMachineKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
            byte[] encrypted = cipher.doFinal(gson.toJson(session).getBytes(StandardCharsets.UTF_8));

            byte[] combined = new byte[IV_LENGTH + encrypted.length];
            System.arraycopy(iv, 0, combined, 0, IV_LENGTH);
            System.arraycopy(encrypted, 0, combined, IV_LENGTH, encrypted.length);
            Files.write(sessionFile, combined);
        } catch (Exception e) {
            System.err.println("Не удалось сохранить сессию: " + e.getMessage());
        }
    }

    private SecretKey deriveMachineKey() throws Exception {
        String fingerprint = System.getProperty("user.name") + "@" + System.getProperty("os.name") + ":OmegaIA";
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(fingerprint.getBytes(StandardCharsets.UTF_8));
        return new SecretKeySpec(hash, "AES");
    }

    public record AuthResult(boolean ok, SessionData session, String error) {
        public static AuthResult success(SessionData session) { return new AuthResult(true, session, null); }
        public static AuthResult failure(String error) { return new AuthResult(false, null, error); }
    }
}
