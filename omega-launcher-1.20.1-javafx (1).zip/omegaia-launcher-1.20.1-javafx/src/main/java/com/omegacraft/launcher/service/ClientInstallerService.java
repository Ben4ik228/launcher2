package com.omegacraft.launcher.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.omegacraft.launcher.model.LauncherConfig;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Автоматический установщик клиента Minecraft 1.20.1 + Forge 47.3.0.
 * Скачивает официальный клиент, библиотеки, нативы и ресурсы напрямую с серверов Mojang,
 * затем устанавливает Forge в headless-режиме (или распаковывает готовый архив клиента).
 */
public class ClientInstallerService {
    private static final String MOJANG_MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
    private static final String RESOURCES_BASE_URL = "https://resources.download.minecraft.net/";
    private static final String FORGE_MAVEN_TEMPLATE = "https://maven.minecraftforge.net/net/minecraftforge/forge/%s-%s/forge-%s-%s-installer.jar";

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .build();
    private final Path gameDirectory;
    private final LauncherConfig config;

    public ClientInstallerService(Path gameDirectory, LauncherConfig config) {
        this.gameDirectory = gameDirectory;
        this.config = config;
    }

    public String resolveForgeVersionId() {
        return config.getMinecraftVersion() + "-forge-" + config.getForgeVersion();
    }

    public void ensureClientInstalled(BiConsumer<Integer, String> progress) throws IOException {
        Files.createDirectories(gameDirectory);
        String mcVersion = config.getMinecraftVersion();
        String forgeVer = config.getForgeVersion();
        String forgeId = resolveForgeVersionId();
        Path forgeJson = gameDirectory.resolve("versions").resolve(forgeId).resolve(forgeId + ".json");

        String customArchive = ModSyncService.normalizeDirectUrl(config.getClientArchiveUrl());
        if (!customArchive.isBlank() && !Files.exists(forgeJson)) {
            installFromCustomArchive(customArchive, progress);
            if (Files.exists(forgeJson)) {
                return;
            }
        }

        if (Files.exists(forgeJson)) {
            Path vanillaJar = gameDirectory.resolve("versions").resolve(mcVersion).resolve(mcVersion + ".jar");
            if (Files.exists(vanillaJar)) {
                progress.accept(55, "Клиент Minecraft " + mcVersion + " + Forge " + forgeVer + " уже установлен.");
                return;
            }
        }

        installVanillaClient(mcVersion, progress);
        installForgeClient(mcVersion, forgeVer, forgeId, progress);
    }

    private void installFromCustomArchive(String archiveUrl, BiConsumer<Integer, String> progress) throws IOException {
        Path tempZip = gameDirectory.resolve("client-archive-temp.zip");
        progress.accept(8, "Скачивание готового архива клиента...");
        downloadFile(archiveUrl, tempZip, null);

        progress.accept(35, "Распаковка клиента в " + gameDirectory.getFileName() + "...");
        try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(tempZip))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                Path target = gameDirectory.resolve(entry.getName()).normalize();
                if (!target.startsWith(gameDirectory)) continue;
                if (entry.isDirectory()) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    Files.copy(zis, target, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        } finally {
            Files.deleteIfExists(tempZip);
        }
        progress.accept(58, "Готовый клиент распакован.");
    }

    private void installVanillaClient(String mcVersion, BiConsumer<Integer, String> progress) throws IOException {
        progress.accept(4, "Загрузка индекса версий Minecraft " + mcVersion + "...");
        Path versionDir = gameDirectory.resolve("versions").resolve(mcVersion);
        Files.createDirectories(versionDir);
        Path versionJsonPath = versionDir.resolve(mcVersion + ".json");

        if (!Files.exists(versionJsonPath)) {
            String manifestBody = fetchString(MOJANG_MANIFEST_URL);
            JsonObject manifest = JsonParser.parseString(manifestBody).getAsJsonObject();
            String versionUrl = null;
            for (JsonElement el : manifest.getAsJsonArray("versions")) {
                JsonObject v = el.getAsJsonObject();
                if (mcVersion.equals(v.get("id").getAsString())) {
                    versionUrl = v.get("url").getAsString();
                    break;
                }
            }
            if (versionUrl == null) {
                throw new IOException("Версия Minecraft " + mcVersion + " не найдена в списке загрузок.");
            }
            downloadFile(versionUrl, versionJsonPath, null);
        }

        JsonObject versionJson = JsonParser.parseString(Files.readString(versionJsonPath, StandardCharsets.UTF_8)).getAsJsonObject();

        // 1. Client JAR
        JsonObject clientDl = versionJson.getAsJsonObject("downloads").getAsJsonObject("client");
        Path clientJarPath = versionDir.resolve(mcVersion + ".jar");
        progress.accept(8, "Скачивание ядра Minecraft " + mcVersion + "...");
        downloadFile(clientDl.get("url").getAsString(), clientJarPath, clientDl.get("sha1").getAsString());

        // 2. Libraries & Natives
        Path libsDir = gameDirectory.resolve("libraries");
        Path nativesDir = gameDirectory.resolve("natives").resolve(mcVersion);
        Files.createDirectories(libsDir);
        Files.createDirectories(nativesDir);

        JsonArray libraries = versionJson.getAsJsonArray("libraries");
        int libTotal = Math.max(1, libraries.size());
        String osKey = currentMojangOs();

        for (int i = 0; i < libraries.size(); i++) {
            JsonObject lib = libraries.get(i).getAsJsonObject();
            if (!isRulesAllowed(lib.getAsJsonArray("rules"))) {
                continue;
            }
            if (i % 6 == 0) {
                int pct = 10 + (i * 15) / libTotal;
                progress.accept(pct, "Загрузка библиотек Java/LWJGL (" + (i + 1) + "/" + libTotal + ")...");
            }

            JsonObject downloads = lib.getAsJsonObject("downloads");
            if (downloads == null) continue;

            if (downloads.has("artifact")) {
                JsonObject artifact = downloads.getAsJsonObject("artifact");
                Path dest = libsDir.resolve(artifact.get("path").getAsString()).normalize();
                if (dest.startsWith(libsDir)) {
                    String sha1 = artifact.has("sha1") ? artifact.get("sha1").getAsString() : null;
                    downloadFile(artifact.get("url").getAsString(), dest, sha1);
                    String fileName = dest.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (fileName.contains("natives-" + osKey) || fileName.contains("natives-" + normalizeArchOs(osKey))) {
                        extractNatives(dest, nativesDir);
                    }
                }
            }

            if (downloads.has("classifiers") && lib.has("natives")) {
                JsonObject nativesMap = lib.getAsJsonObject("natives");
                if (nativesMap.has(osKey)) {
                    String classifierKey = nativesMap.get(osKey).getAsString();
                    JsonObject classifiers = downloads.getAsJsonObject("classifiers");
                    if (classifiers.has(classifierKey)) {
                        JsonObject nativeArt = classifiers.getAsJsonObject(classifierKey);
                        Path dest = libsDir.resolve(nativeArt.get("path").getAsString()).normalize();
                        if (dest.startsWith(libsDir)) {
                            String sha1 = nativeArt.has("sha1") ? nativeArt.get("sha1").getAsString() : null;
                            downloadFile(nativeArt.get("url").getAsString(), dest, sha1);
                            extractNatives(dest, nativesDir);
                        }
                    }
                }
            }
        }

        // 3. Assets Index & Resources
        JsonObject assetIndex = versionJson.getAsJsonObject("assetIndex");
        String assetIndexId = assetIndex.get("id").getAsString();
        Path assetsDir = gameDirectory.resolve("assets");
        Path indexesDir = assetsDir.resolve("indexes");
        Path objectsDir = assetsDir.resolve("objects");
        Files.createDirectories(indexesDir);
        Files.createDirectories(objectsDir);

        Path indexFile = indexesDir.resolve(assetIndexId + ".json");
        downloadFile(assetIndex.get("url").getAsString(), indexFile, assetIndex.has("sha1") ? assetIndex.get("sha1").getAsString() : null);

        JsonObject objects = JsonParser.parseString(Files.readString(indexFile, StandardCharsets.UTF_8))
                .getAsJsonObject().getAsJsonObject("objects");

        List<String[]> missingAssets = new ArrayList<>();
        for (Map.Entry<String, JsonElement> entry : objects.entrySet()) {
            JsonObject obj = entry.getValue().getAsJsonObject();
            String hash = obj.get("hash").getAsString();
            String prefix = hash.substring(0, 2);
            Path objPath = objectsDir.resolve(prefix).resolve(hash);
            if (!Files.exists(objPath) || objPath.toFile().length() != obj.get("size").getAsLong()) {
                missingAssets.add(new String[]{prefix, hash});
            }
        }

        if (!missingAssets.isEmpty()) {
            int totalAssets = missingAssets.size();
            AtomicInteger done = new AtomicInteger(0);
            ExecutorService pool = Executors.newFixedThreadPool(8);
            List<Future<?>> futures = new ArrayList<>();
            for (String[] asset : missingAssets) {
                futures.add(pool.submit(() -> {
                    String prefix = asset[0];
                    String hash = asset[1];
                    Path target = objectsDir.resolve(prefix).resolve(hash);
                    String url = RESOURCES_BASE_URL + prefix + "/" + hash;
                    downloadFile(url, target, hash);
                    int finished = done.incrementAndGet();
                    if (finished % 40 == 0 || finished == totalAssets) {
                        int pct = 25 + (finished * 25) / totalAssets;
                        progress.accept(pct, "Загрузка ресурсов Minecraft (" + finished + "/" + totalAssets + ")...");
                    }
                    return null;
                }));
            }
            try {
                for (Future<?> f : futures) {
                    f.get();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Загрузка ресурсов прервана.", e);
            } catch (ExecutionException e) {
                throw new IOException("Ошибка загрузки ресурсов: " + e.getCause().getMessage(), e.getCause());
            } finally {
                pool.shutdownNow();
            }
        }
    }

    private void installForgeClient(
            String mcVersion,
            String forgeVersion,
            String forgeId,
            BiConsumer<Integer, String> progress
    ) throws IOException {
        Path forgeJson = gameDirectory.resolve("versions").resolve(forgeId).resolve(forgeId + ".json");
        if (Files.exists(forgeJson)) {
            return;
        }

        // Forge --installClient требует наличия launcher_profiles.json в корне gameDir
        Path profilesFile = gameDirectory.resolve("launcher_profiles.json");
        if (!Files.exists(profilesFile)) {
            Files.writeString(profilesFile, "{\"profiles\":{}}", StandardCharsets.UTF_8);
        }

        String installerUrl = String.format(FORGE_MAVEN_TEMPLATE, mcVersion, forgeVersion, mcVersion, forgeVersion);
        Path installerJar = gameDirectory.resolve("forge-" + mcVersion + "-" + forgeVersion + "-installer.jar");

        progress.accept(52, "Скачивание установщика Forge " + forgeVersion + "...");
        downloadFile(installerUrl, installerJar, null);

        progress.accept(56, "Установка Forge " + forgeVersion + " (может занять до 1 минуты)...");
        String javaBin = resolveJavaExecutable(false);
        ProcessBuilder pb = new ProcessBuilder(
                javaBin,
                "-jar",
                installerJar.toAbsolutePath().toString(),
                "--installClient",
                gameDirectory.toAbsolutePath().toString()
        );
        pb.directory(gameDirectory.toFile());
        pb.redirectErrorStream(true);

        Process proc = pb.start();
        StringBuilder logTail = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (logTail.length() > 3000) logTail.delete(0, 1500);
                logTail.append(line).append('\n');
            }
        }

        try {
            int exit = proc.waitFor();
            if (exit != 0 || !Files.exists(forgeJson)) {
                throw new IOException("Не удалось установить Forge " + forgeVersion + " (код " + exit + "): " + logTail);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Установка Forge прервана.", e);
        } finally {
            Files.deleteIfExists(installerJar);
        }
        progress.accept(62, "Forge " + forgeVersion + " успешно установлен.");
    }

    private void extractNatives(Path jarFile, Path nativesDir) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(jarFile))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String name = entry.getName();
                if (name.startsWith("META-INF/")) continue;
                if (name.endsWith(".dll") || name.endsWith(".so") || name.endsWith(".dylib") || name.endsWith(".jnilib")) {
                    String baseName = Paths.get(name).getFileName().toString();
                    Path out = nativesDir.resolve(baseName).normalize();
                    if (out.startsWith(nativesDir)) {
                        Files.copy(zis, out, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
        }
    }

    private String fetchString(String url) throws IOException {
        Request request = new Request.Builder().url(url).get().build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                throw new IOException("HTTP " + response.code() + " при обращении к " + url);
            }
            return response.body().string();
        }
    }

    private void downloadFile(String url, Path dest, String expectedSha1) throws IOException {
        if (Files.exists(dest) && expectedSha1 != null && !expectedSha1.isBlank()) {
            try (InputStream is = Files.newInputStream(dest)) {
                if (expectedSha1.equalsIgnoreCase(DigestUtils.sha1Hex(is))) {
                    return;
                }
            }
        }

        Files.createDirectories(dest.getParent());
        Path part = dest.resolveSibling(dest.getFileName().toString() + ".part");
        Request request = new Request.Builder().url(url).get().build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                throw new IOException("Не удалось скачать " + url + " (HTTP " + response.code() + ")");
            }
            try (InputStream in = response.body().byteStream();
                 OutputStream out = Files.newOutputStream(part)) {
                in.transferTo(out);
            }
        }

        if (expectedSha1 != null && !expectedSha1.isBlank()) {
            try (InputStream is = Files.newInputStream(part)) {
                String actual = DigestUtils.sha1Hex(is);
                if (!expectedSha1.equalsIgnoreCase(actual)) {
                    Files.deleteIfExists(part);
                    throw new IOException("Повреждённый файл при загрузке: " + dest.getFileName());
                }
            }
        }
        Files.move(part, dest, StandardCopyOption.REPLACE_EXISTING);
    }

    public static boolean isRulesAllowed(JsonArray rules) {
        if (rules == null || rules.isEmpty()) return true;
        boolean allowed = false;
        String currentOs = currentMojangOs();
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        for (JsonElement el : rules) {
            JsonObject rule = el.getAsJsonObject();
            String action = rule.get("action").getAsString();
            boolean matches = true;
            if (rule.has("os")) {
                JsonObject osObj = rule.getAsJsonObject("os");
                if (osObj.has("name") && !currentOs.equals(osObj.get("name").getAsString())) {
                    matches = false;
                }
                if (matches && osObj.has("arch")) {
                    String expectedArch = osObj.get("arch").getAsString();
                    boolean isX86 = arch.equals("x86") || arch.equals("i386") || arch.equals("i686");
                    boolean isArm64 = arch.contains("aarch64") || arch.contains("arm64");
                    if ("x86".equals(expectedArch) && !isX86) matches = false;
                    if ("arm64".equals(expectedArch) && !isArm64) matches = false;
                }
                if (matches && osObj.has("version")) {
                    String osVer = System.getProperty("os.version", "");
                    if (!Pattern.compile(osObj.get("version").getAsString()).matcher(osVer).find()) {
                        matches = false;
                    }
                }
            }
            if (rule.has("features")) {
                matches = false; // Игнорируем demo/quickPlay-specific JVM overrides при сборе библиотек
            }
            if (matches) {
                allowed = "allow".equals(action);
            }
        }
        return allowed;
    }

    public static String currentMojangOs() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("win")) return "windows";
        if (os.contains("mac")) return "osx";
        return "linux";
    }

    private static String normalizeArchOs(String osKey) {
        if ("osx".equals(osKey)) return "macos";
        return osKey;
    }

    /**
     * Находит рабочий java.exe / javaw.exe (встроенный runtime в OmegaLauncher или системную Java 17+).
     */
    public static String resolveJavaExecutable(boolean preferWindowless) {
        boolean isWin = currentMojangOs().equals("windows");
        List<Path> candidates = new ArrayList<>();
        String javaHome = System.getProperty("java.home", "");
        if (!javaHome.isBlank()) {
            Path bin = Path.of(javaHome, "bin");
            if (isWin) {
                if (preferWindowless) candidates.add(bin.resolve("javaw.exe"));
                candidates.add(bin.resolve("java.exe"));
                if (!preferWindowless) candidates.add(bin.resolve("javaw.exe"));
            }
            candidates.add(bin.resolve("java"));
        }

        String envHome = System.getenv("JAVA_HOME");
        if (envHome != null && !envHome.isBlank()) {
            Path bin = Path.of(envHome, "bin");
            if (isWin) {
                if (preferWindowless) candidates.add(bin.resolve("javaw.exe"));
                candidates.add(bin.resolve("java.exe"));
            }
            candidates.add(bin.resolve("java"));
        }

        String pathEnv = System.getenv("PATH");
        if (pathEnv != null && !pathEnv.isBlank()) {
            for (String dir : pathEnv.split(Pattern.quote(File.pathSeparator))) {
                if (dir.isBlank()) continue;
                Path bin = Path.of(dir);
                if (isWin) {
                    if (preferWindowless) candidates.add(bin.resolve("javaw.exe"));
                    candidates.add(bin.resolve("java.exe"));
                } else {
                    candidates.add(bin.resolve("java"));
                }
            }
        }

        if (isWin) {
            String[] roots = {
                    System.getenv("ProgramFiles") + "\\Eclipse Adoptium",
                    System.getenv("ProgramFiles") + "\\Java",
                    System.getenv("ProgramFiles") + "\\BellSoft",
                    System.getenv("ProgramFiles") + "\\Microsoft",
                    System.getenv("ProgramFiles") + "\\Zulu"
            };
            for (String rootStr : roots) {
                if (rootStr.startsWith("null")) continue;
                Path rootDir = Path.of(rootStr);
                if (Files.isDirectory(rootDir)) {
                    try (DirectoryStream<Path> ds = Files.newDirectoryStream(rootDir)) {
                        for (Path sub : ds) {
                            if (preferWindowless) candidates.add(sub.resolve("bin").resolve("javaw.exe"));
                            candidates.add(sub.resolve("bin").resolve("java.exe"));
                        }
                    } catch (IOException ignored) {
                    }
                }
            }
        }

        for (Path p : candidates) {
            try {
                if (Files.isRegularFile(p)) {
                    return p.toAbsolutePath().toString();
                }
            } catch (Exception ignored) {
            }
        }
        return isWin ? "java.exe" : "java";
    }
}
