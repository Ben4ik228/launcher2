package com.omegacraft.launcher.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.ModManifest;
import com.omegacraft.launcher.model.SessionData;
import com.omegacraft.launcher.security.DllSecurityGuard;
import com.omegacraft.launcher.security.IntegrityVerifier;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Запускает Minecraft 1.20.1 (Forge BootstrapLauncher или Vanilla) с полным classpath из JSON-профилей,
 * блокирует запуск без обязательных модов или со сторонними DLL и контролирует процесс в реальном времени.
 */
public class MinecraftLauncher {
    private final Path gameDirectory;
    private final LauncherConfig config;

    public MinecraftLauncher(Path gameDirectory, LauncherConfig config) {
        this.gameDirectory = gameDirectory;
        this.config = config;
    }

    public LaunchSession launch(SessionData session, List<ModManifest.ModItem> expectedMods) throws IOException {
        if (config.isStrictAntiCheat()) {
            IntegrityVerifier verifier = new IntegrityVerifier(gameDirectory, config);
            verifier.sanitizeNativeLibraries(config.getMinecraftVersion());
            verifier.assertAllRequiredModsPresent(expectedMods);
        }

        String mcVersion = config.getMinecraftVersion();
        String forgeId = mcVersion + "-forge-" + config.getForgeVersion();
        Path vanillaJsonPath = gameDirectory.resolve("versions").resolve(mcVersion).resolve(mcVersion + ".json");
        Path forgeJsonPath = gameDirectory.resolve("versions").resolve(forgeId).resolve(forgeId + ".json");

        Path nativesDir = gameDirectory.resolve("natives").resolve(mcVersion);
        Path assetsDir = gameDirectory.resolve("assets");
        Path libsDir = gameDirectory.resolve("libraries");
        String sep = System.getProperty("path.separator");

        List<String> cmd = new ArrayList<>();
        cmd.add(ClientInstallerService.resolveJavaExecutable(true));
        cmd.add("-Xms1024M");
        cmd.add("-Xmx" + config.getRamMb() + "M");
        cmd.add("-XX:+DisableAttachMechanism");
        cmd.add("-Domegacraft.server=" + config.getServerName());

        if (Files.exists(forgeJsonPath) && Files.exists(vanillaJsonPath)) {
            JsonObject vanillaJson = JsonParser.parseString(Files.readString(vanillaJsonPath, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject forgeJson = JsonParser.parseString(Files.readString(forgeJsonPath, StandardCharsets.UTF_8)).getAsJsonObject();

            String classpath = buildMergedClasspath(libsDir, mcVersion, forgeJson, vanillaJson, sep);
            String assetIndex = vanillaJson.has("assetIndex")
                    ? vanillaJson.getAsJsonObject("assetIndex").get("id").getAsString()
                    : "5";

            Map<String, String> vars = new HashMap<>();
            vars.put("${natives_directory}", nativesDir.toAbsolutePath().toString());
            vars.put("${launcher_name}", "OmegaIALauncher");
            vars.put("${launcher_version}", config.getLauncherVersion());
            vars.put("${classpath}", classpath);
            vars.put("${library_directory}", libsDir.toAbsolutePath().toString());
            vars.put("${classpath_separator}", sep);
            vars.put("${version_name}", forgeId);
            vars.put("${auth_player_name}", session.getUsername());
            vars.put("${game_directory}", gameDirectory.toAbsolutePath().toString());
            vars.put("${assets_root}", assetsDir.toAbsolutePath().toString());
            vars.put("${assets_index_name}", assetIndex);
            vars.put("${auth_uuid}", session.getUuid());
            vars.put("${auth_access_token}", session.getAccessToken());
            vars.put("${clientid}", "omega");
            vars.put("${auth_xuid}", "0");
            vars.put("${user_type}", "msa");
            vars.put("${version_type}", "release");

            appendArguments(cmd, vanillaJson, "jvm", vars);
            appendArguments(cmd, forgeJson, "jvm", vars);

            if (!cmd.contains("-cp") && !cmd.contains("--class-path")) {
                cmd.add("-cp");
                cmd.add(classpath);
            }

            String mainClass = forgeJson.has("mainClass")
                    ? forgeJson.get("mainClass").getAsString()
                    : "cpw.mods.bootstraplauncher.BootstrapLauncher";
            cmd.add(mainClass);

            appendArguments(cmd, vanillaJson, "game", vars);
            appendArguments(cmd, forgeJson, "game", vars);

            cmd.add("--quickPlayMultiplayer");
            cmd.add(config.getServerAddress() + ":" + config.getServerPort());
        } else {
            Path clientJar = gameDirectory.resolve("versions").resolve(mcVersion).resolve(mcVersion + ".jar");
            cmd.add("-Djava.library.path=" + nativesDir.toAbsolutePath());
            cmd.add("-cp");
            cmd.add(walkAllLibrariesClasspath(libsDir, clientJar, sep));
            cmd.add("net.minecraft.client.main.Main");
            cmd.add("--username");
            cmd.add(session.getUsername());
            cmd.add("--version");
            cmd.add(mcVersion);
            cmd.add("--gameDir");
            cmd.add(gameDirectory.toAbsolutePath().toString());
            cmd.add("--assetsDir");
            cmd.add(assetsDir.toAbsolutePath().toString());
            cmd.add("--assetIndex");
            cmd.add("5");
            cmd.add("--uuid");
            cmd.add(session.getUuid());
            cmd.add("--accessToken");
            cmd.add(session.getAccessToken());
            cmd.add("--userType");
            cmd.add("msa");
            cmd.add("--quickPlayMultiplayer");
            cmd.add(config.getServerAddress() + ":" + config.getServerPort());
        }

        Files.createDirectories(gameDirectory.resolve("logs"));
        Path launcherLog = gameDirectory.resolve("logs").resolve("launcher-mc.log");

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(gameDirectory.toFile());
        pb.redirectErrorStream(true);
        Process process = pb.start();

        List<String> outputTail = Collections.synchronizedList(new ArrayList<>());
        Thread logThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
                 BufferedWriter fileOut = Files.newBufferedWriter(launcherLog, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    fileOut.write(line);
                    fileOut.newLine();
                    fileOut.flush();
                    synchronized (outputTail) {
                        if (outputTail.size() >= 120) {
                            outputTail.remove(0);
                        }
                        outputTail.add(line);
                    }
                }
            } catch (IOException ignored) {
            }
        }, "Omega-MC-Log-Reader");
        logThread.setDaemon(true);
        logThread.start();

        startRuntimeModsGuard(process, expectedMods, outputTail);
        return new LaunchSession(process, outputTail, logThread);
    }

    public int waitForExit(LaunchSession session) throws InterruptedException {
        int code = session.process().waitFor();
        session.logThread().join(1500);
        return code;
    }

    public String extractCrashMessage(LaunchSession session, int exitCode) {
        List<String> lines = new ArrayList<>();
        synchronized (session.outputTail()) {
            lines.addAll(session.outputTail());
        }
        String found = pickBestErrorLine(lines);
        if (found == null) {
            Path latestLog = gameDirectory.resolve("logs").resolve("latest.log");
            if (Files.exists(latestLog)) {
                try {
                    List<String> all = Files.readAllLines(latestLog, StandardCharsets.UTF_8);
                    int start = Math.max(0, all.size() - 100);
                    found = pickBestErrorLine(all.subList(start, all.size()));
                    if (found == null && !all.isEmpty()) {
                        for (int i = all.size() - 1; i >= start; i--) {
                            String l = all.get(i).trim();
                            if (!l.isEmpty()) {
                                found = l;
                                break;
                            }
                        }
                    }
                } catch (IOException ignored) {
                }
            }
        }
        if (found == null && !lines.isEmpty()) {
            for (int i = lines.size() - 1; i >= 0; i--) {
                String l = lines.get(i).trim();
                if (!l.isEmpty()) {
                    found = l;
                    break;
                }
            }
        }
        if (found == null) {
            return "Непредвиденный сбой (код " + exitCode + "). Подробности в logs/latest.log";
        }
        String clean = found.replaceAll("\\s+", " ").trim();
        if (clean.length() > 190) {
            clean = clean.substring(0, 187) + "...";
        }
        return clean + " (подробности в logs/latest.log)";
    }

    private static String pickBestErrorLine(List<String> lines) {
        for (int i = lines.size() - 1; i >= 0; i--) {
            String line = lines.get(i);
            String lower = line.toLowerCase(Locale.ROOT);
            if (lower.contains("[anti-cheat]") || lower.contains("caused by:")
                    || lower.contains("exception") || lower.contains("fatal")
                    || lower.contains("/error]") || lower.contains("unsatisfied")
                    || lower.contains("missing") && !lower.contains("missing mods.toml")) {
                return line;
            }
        }
        return null;
    }

    private String buildMergedClasspath(
            Path libsDir,
            String mcVersion,
            JsonObject forgeJson,
            JsonObject vanillaJson,
            String sep
    ) {
        Map<String, String> byCoordKey = new LinkedHashMap<>();
        collectLibraries(libsDir, vanillaJson.getAsJsonArray("libraries"), byCoordKey);
        collectLibraries(libsDir, forgeJson.getAsJsonArray("libraries"), byCoordKey);

        // Для Forge 1.20.1 используется client-srg.jar из libraries/net/minecraft/client,
        // обфусцированный versions/1.20.1/1.20.1.jar не должен попадать в -cp BootstrapLauncher.
        List<String> entries = new ArrayList<>(byCoordKey.values());
        return String.join(sep, entries);
    }

    private void collectLibraries(Path libsDir, JsonArray libraries, Map<String, String> outByKey) {
        if (libraries == null) return;
        for (JsonElement el : libraries) {
            JsonObject lib = el.getAsJsonObject();
            if (!ClientInstallerService.isRulesAllowed(lib.getAsJsonArray("rules"))) {
                continue;
            }
            if (!lib.has("downloads")) continue;
            JsonObject downloads = lib.getAsJsonObject("downloads");
            if (!downloads.has("artifact")) continue;
            JsonObject artifact = downloads.getAsJsonObject("artifact");
            String relPath = artifact.get("path").getAsString();
            Path jarPath = libsDir.resolve(relPath).normalize();
            if (!Files.exists(jarPath)) continue;

            String key = lib.has("name") ? stripVersion(lib.get("name").getAsString()) : relPath;
            outByKey.put(key, jarPath.toAbsolutePath().toString());
        }
    }

    private static String stripVersion(String mavenCoord) {
        String[] parts = mavenCoord.split(":");
        if (parts.length >= 4) {
            return parts[0] + ":" + parts[1] + ":" + parts[3];
        }
        if (parts.length >= 2) {
            return parts[0] + ":" + parts[1];
        }
        return mavenCoord;
    }

    private void appendArguments(List<String> cmd, JsonObject versionJson, String section, Map<String, String> vars) {
        if (!versionJson.has("arguments")) return;
        JsonObject argsObj = versionJson.getAsJsonObject("arguments");
        if (!argsObj.has(section)) return;
        JsonArray arr = argsObj.getAsJsonArray(section);
        for (JsonElement el : arr) {
            if (el.isJsonPrimitive()) {
                cmd.add(substituteVars(el.getAsString(), vars));
            } else if (el.isJsonObject()) {
                JsonObject obj = el.getAsJsonObject();
                if (!ClientInstallerService.isRulesAllowed(obj.getAsJsonArray("rules"))) {
                    continue;
                }
                JsonElement val = obj.get("value");
                if (val == null) continue;
                if (val.isJsonPrimitive()) {
                    cmd.add(substituteVars(val.getAsString(), vars));
                } else if (val.isJsonArray()) {
                    for (JsonElement v : val.getAsJsonArray()) {
                        cmd.add(substituteVars(v.getAsString(), vars));
                    }
                }
            }
        }
    }

    private static String substituteVars(String arg, Map<String, String> vars) {
        String res = arg;
        for (Map.Entry<String, String> e : vars.entrySet()) {
            res = res.replace(e.getKey(), e.getValue());
        }
        return res;
    }

    private String walkAllLibrariesClasspath(Path libsDir, Path clientJar, String sep) throws IOException {
        List<String> entries = new ArrayList<>();
        if (Files.exists(libsDir)) {
            try (var walk = Files.walk(libsDir)) {
                walk.filter(p -> p.toString().endsWith(".jar"))
                        .forEach(p -> entries.add(p.toAbsolutePath().toString()));
            }
        }
        entries.add(clientJar.toAbsolutePath().toString());
        return String.join(sep, entries);
    }

    private void startRuntimeModsGuard(
            Process mcProcess,
            List<ModManifest.ModItem> expectedMods,
            List<String> outputTail
    ) {
        if (!config.isStrictAntiCheat()) return;
        Map<String, String> allowedShaByName = new HashMap<>();
        List<ModManifest.ModItem> sourceMods = expectedMods;
        if (sourceMods == null || sourceMods.isEmpty()) {
            ModManifest saved = new ModSyncService(gameDirectory).readSavedSyncedManifest();
            if (saved != null) {
                sourceMods = saved.getMods();
            }
        }
        if (sourceMods != null) {
            for (ModManifest.ModItem m : sourceMods) {
                if (m.getFileName() != null) {
                    allowedShaByName.put(m.getFileName().toLowerCase(Locale.ROOT), m.getSha256() == null ? "" : m.getSha256());
                }
            }
        }

        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "Omega-Runtime-AntiCheat");
            t.setDaemon(true);
            return t;
        });
        executor.execute(() -> {
            try (WatchService watcher = FileSystems.getDefault().newWatchService()) {
                Path modsDir = gameDirectory.resolve("mods");
                Files.createDirectories(modsDir);
                modsDir.register(
                        watcher,
                        StandardWatchEventKinds.ENTRY_CREATE,
                        StandardWatchEventKinds.ENTRY_MODIFY,
                        StandardWatchEventKinds.ENTRY_DELETE
                );
                while (mcProcess.isAlive()) {
                    WatchKey key = watcher.poll(2, java.util.concurrent.TimeUnit.SECONDS);
                    if (key != null) {
                        key.pollEvents();
                        key.reset();
                        Thread.sleep(150);
                    }

                    String violation = checkModsViolation(modsDir, allowedShaByName);
                    if (violation == null) {
                        violation = DllSecurityGuard.scanProcessModules(mcProcess.pid(), gameDirectory);
                    }
                    if (violation != null) {
                        synchronized (outputTail) {
                            outputTail.add(violation);
                        }
                        System.err.println(violation);
                        mcProcess.destroyForcibly();
                        break;
                    }
                }
            } catch (Exception ignored) {
            } finally {
                executor.shutdownNow();
            }
        });
    }

    private static String checkModsViolation(Path modsDir, Map<String, String> allowedShaByName) {
        if (allowedShaByName.isEmpty()) {
            return null;
        }
        Set<String> seenLower = new HashSet<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(modsDir)) {
            for (Path file : stream) {
                if (Files.isDirectory(file)) {
                    String dirName = file.getFileName().toString();
                    if (!dirName.startsWith(".")) {
                        return "Обнаружена посторонняя папка в mods/: " + dirName;
                    }
                    continue;
                }
                String nameLower = file.getFileName().toString().toLowerCase(Locale.ROOT);
                String expectedSha = allowedShaByName.get(nameLower);
                if (expectedSha == null) {
                    return "Попытка подкинуть сторонний файл в mods/: " + file.getFileName();
                }
                seenLower.add(nameLower);
                if (!expectedSha.isBlank()) {
                    String actualSha = IntegrityVerifier.computeSha256(file);
                    if (!actualSha.equalsIgnoreCase(expectedSha)) {
                        return "Файл мода был изменён во время игры: " + file.getFileName();
                    }
                }
            }
        } catch (IOException ignored) {
        }

        for (String requiredName : allowedShaByName.keySet()) {
            if (!seenLower.contains(requiredName)) {
                return "Удалён обязательный мод (" + requiredName + "). Запуск без модов запрещён!";
            }
        }
        return null;
    }

    public record LaunchSession(Process process, List<String> outputTail, Thread logThread) {}
}
