package com.omegacraft.launcher.security;

import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.ModManifest;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.util.*;

/**
 * Модуль проверки целостности лаунчера и античит-защиты папки модов.
 * 1) Проверяет SHA-256 собственного JAR-файла лаунчера (защита от подмены).
 * 2) Удаляет/отправляет в карантин любые сторонние моды, читы и ресурспаки-читы.
 * 3) Проверяет SHA-256 каждого разрешённого мода перед запуском Minecraft 1.20.1.
 */
public class IntegrityVerifier {
    private final Path gameDirectory;
    private final Path modsDirectory;
    private final Path quarantineDirectory;
    private final LauncherConfig config;

    public IntegrityVerifier(Path gameDirectory, LauncherConfig config) {
        this.gameDirectory = gameDirectory;
        this.modsDirectory = gameDirectory.resolve("mods");
        this.quarantineDirectory = gameDirectory.resolve("quarantine");
        this.config = config;
    }

    public SelfCheckResult verifyLauncherBinary() {
        try {
            Path jarPath = Paths.get(
                    IntegrityVerifier.class.getProtectionDomain().getCodeSource().getLocation().toURI()
            );
            if (Files.isDirectory(jarPath)) {
                // Запуск из IDE / mvn javafx:run (без упакованного JAR)
                return new SelfCheckResult(true, "DEV_MODE", "Запуск из исходного кода (режим разработки).");
            }
            String actualHash = computeSha256(jarPath);
            String expected = config.getExpectedLauncherSha256();
            if (expected != null && !expected.isBlank()
                    && !expected.equals("SELF_VERIFY_MANIFEST_OR_PINNED_HASH")
                    && !expected.equalsIgnoreCase(actualHash)) {
                return new SelfCheckResult(false, actualHash, "Контрольная сумма лаунчера не совпадает!");
            }
            return new SelfCheckResult(true, actualHash, "Целостность лаунчера подтверждена.");
        } catch (URISyntaxException | IOException e) {
            return new SelfCheckResult(false, "", "Ошибка проверки JAR: " + e.getMessage());
        }
    }

    public ModAuditReport sanitizeAndAuditMods(ModManifest manifest) throws IOException {
        Files.createDirectories(modsDirectory);
        Files.createDirectories(quarantineDirectory);

        Map<String, ModManifest.ModItem> allowedByFile = new HashMap<>();
        for (ModManifest.ModItem item : manifest.getMods()) {
            allowedByFile.put(item.getFileName().toLowerCase(Locale.ROOT), item);
        }

        List<String> quarantined = new ArrayList<>();
        List<ModManifest.ModItem> needsDownload = new ArrayList<>();
        Set<String> presentValid = new HashSet<>();

        // Удаляем любые лишние файлы, читы, классы, архивы, которых нет в манифесте
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(modsDirectory)) {
            for (Path file : stream) {
                if (Files.isDirectory(file)) {
                    // Вложенные папки в mods/ запрещены (часто используют для подгрузки читов)
                    deleteRecursively(file);
                    quarantined.add(file.getFileName().toString() + "/");
                    continue;
                }
                String nameLower = file.getFileName().toString().toLowerCase(Locale.ROOT);
                ModManifest.ModItem expectedMod = allowedByFile.get(nameLower);
                if (expectedMod == null) {
                    Path target = quarantineDirectory.resolve(System.currentTimeMillis() + "_" + file.getFileName());
                    Files.move(file, target, StandardCopyOption.REPLACE_EXISTING);
                    quarantined.add(file.getFileName().toString());
                    continue;
                }
                String actualSha = computeSha256(file);
                if (!actualSha.equalsIgnoreCase(expectedMod.getSha256())) {
                    Files.deleteIfExists(file);
                    needsDownload.add(expectedMod);
                } else {
                    presentValid.add(nameLower);
                }
            }
        }

        for (ModManifest.ModItem item : manifest.getMods()) {
            if (!presentValid.contains(item.getFileName().toLowerCase(Locale.ROOT))
                    && needsDownload.stream().noneMatch(m -> m.getFileName().equalsIgnoreCase(item.getFileName()))) {
                needsDownload.add(item);
            }
        }

        return new ModAuditReport(quarantined, needsDownload, presentValid.size());
    }

    public void assertAllRequiredModsPresent(List<ModManifest.ModItem> expectedMods) throws IOException {
        if (expectedMods == null || expectedMods.isEmpty()) {
            return;
        }
        ModManifest wrapper = new ModManifest();
        wrapper.setMods(expectedMods);
        ModAuditReport report = sanitizeAndAuditMods(wrapper);
        if (!report.modsToDownload().isEmpty()) {
            String missingNames = report.modsToDownload().stream()
                    .map(ModManifest.ModItem::getFileName)
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("unknown");
            throw new IOException("Отсутствуют или повреждены обязательные моды: " + missingNames + ". Запуск без модов заблокирован.");
        }
    }

    public int sanitizeNativeLibraries(String mcVersion) throws IOException {
        Files.createDirectories(quarantineDirectory);
        int blocked = 0;

        // 1. В корне игры, mods/, config/, resourcepacks/, shaderpacks/ любые .dll/.asi запрещены
        List<Path> strictDirs = List.of(
                gameDirectory,
                modsDirectory,
                gameDirectory.resolve("config"),
                gameDirectory.resolve("resourcepacks"),
                gameDirectory.resolve("shaderpacks")
        );
        for (Path dir : strictDirs) {
            if (!Files.isDirectory(dir)) continue;
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
                for (Path file : stream) {
                    if (Files.isDirectory(file)) continue;
                    String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (name.endsWith(".dll") || name.endsWith(".asi") || name.endsWith(".so") || name.endsWith(".dylib")) {
                        quarantineOrThrow(file, "Сторонний нативный модуль в папке клиента: " + file.getFileName());
                        blocked++;
                    }
                }
            }
        }

        // 2. Проверка natives/<mcVersion>/ — разрешены только официальные библиотеки Mojang/LWJGL/JNA
        Path nativesDir = gameDirectory.resolve("natives").resolve(mcVersion);
        if (Files.isDirectory(nativesDir)) {
            try (var walk = Files.walk(nativesDir)) {
                List<Path> nativeFiles = walk.filter(Files::isRegularFile).toList();
                for (Path file : nativeFiles) {
                    String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                    if ((name.endsWith(".dll") || name.endsWith(".so") || name.endsWith(".dylib"))
                            && !isAllowedGameNativeName(name)) {
                        quarantineOrThrow(file, "Обнаружена сторонняя DLL в папке natives/: " + file.getFileName());
                        blocked++;
                    }
                }
            }
        }

        // 3. Проверка прокси-инжекторов (version.dll / winhttp.dll / opengl32.dll и т.д.) рядом с java/лаунчером
        String javaHome = System.getProperty("java.home", "");
        if (!javaHome.isBlank()) {
            Path javaBin = Paths.get(javaHome, "bin");
            checkProxyDllsInDir(javaBin);
        }
        checkProxyDllsInDir(Paths.get("").toAbsolutePath());

        return blocked;
    }

    private void checkProxyDllsInDir(Path dir) throws IOException {
        if (!Files.isDirectory(dir)) return;
        Set<String> hijackNames = Set.of(
                "version.dll", "winhttp.dll", "winmm.dll", "opengl32.dll",
                "dinput8.dll", "dxgi.dll", "xinput1_3.dll", "wsock32.dll", "imgui.dll"
        );
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path file : stream) {
                if (Files.isDirectory(file)) continue;
                String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                if (hijackNames.contains(name)) {
                    throw new IOException("Запуск заблокирован: обнаружена подменная DLL (" + file.getFileName() + ") в " + dir);
                }
            }
        }
    }

    private void quarantineOrThrow(Path file, String reason) throws IOException {
        try {
            Path target = quarantineDirectory.resolve(System.currentTimeMillis() + "_" + file.getFileName());
            Files.move(file, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            throw new IOException(reason + " (не удалось изолировать файл)");
        }
    }

    public static boolean isAllowedGameNativeName(String lowerFileName) {
        return lowerFileName.startsWith("lwjgl")
                || lowerFileName.startsWith("glfw")
                || lowerFileName.startsWith("openal")
                || lowerFileName.startsWith("jemalloc")
                || lowerFileName.startsWith("tinyfd")
                || lowerFileName.startsWith("sapiwrapper")
                || lowerFileName.startsWith("avutil")
                || lowerFileName.startsWith("swresample")
                || lowerFileName.startsWith("jnidispatch")
                || lowerFileName.matches("^jna\\d+\\.dll$")
                || lowerFileName.startsWith("zstd-jni")
                || lowerFileName.startsWith("sqlite")
                || lowerFileName.startsWith("oshi");
    }

    public static String computeSha256(Path file) throws IOException {
        try (InputStream is = Files.newInputStream(file)) {
            return DigestUtils.sha256Hex(is);
        }
    }

    private void deleteRecursively(Path dir) throws IOException {
        try (var walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try { Files.deleteIfExists(path); } catch (IOException ignored) {}
            });
        }
    }

    public record SelfCheckResult(boolean valid, String sha256, String reason) {}
    public record ModAuditReport(List<String> quarantinedFiles, List<ModManifest.ModItem> modsToDownload, int validCount) {}
}
