package com.omegacraft.launcher.model;

import java.util.ArrayList;
import java.util.List;

public class ModManifest {
    private String serverName;
    private String minecraftVersion;
    private String modLoader;
    private String clientVersion;
    private String launcherVersion;
    private String launcherSha256;
    private String optionsTxtUrl;
    private String optionsOfUrl;
    private String clientArchiveUrl;
    private List<ModItem> mods = new ArrayList<>();

    public String getServerName() { return serverName; }
    public String getMinecraftVersion() { return minecraftVersion; }
    public String getModLoader() { return modLoader; }
    public String getClientVersion() { return clientVersion; }
    public String getLauncherVersion() { return launcherVersion; }
    public String getLauncherSha256() { return launcherSha256; }
    public String getOptionsTxtUrl() { return optionsTxtUrl; }
    public String getOptionsOfUrl() { return optionsOfUrl; }
    public String getClientArchiveUrl() { return clientArchiveUrl; }
    public List<ModItem> getMods() { return mods; }
    public void setMods(List<ModItem> mods) { this.mods = mods != null ? mods : new ArrayList<>(); }

    public static class ModItem {
        private String id;
        private String name;
        private String fileName;
        private String version;
        private String sha256;
        private long sizeBytes;
        private String downloadUrl;
        private boolean required = true;

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getFileName() { return fileName; }
        public void setFileName(String fileName) { this.fileName = fileName; }
        public String getVersion() { return version; }
        public void setVersion(String version) { this.version = version; }
        public String getSha256() { return sha256; }
        public void setSha256(String sha256) { this.sha256 = sha256; }
        public long getSizeBytes() { return sizeBytes; }
        public void setSizeBytes(long sizeBytes) { this.sizeBytes = sizeBytes; }
        public String getDownloadUrl() { return downloadUrl; }
        public void setDownloadUrl(String downloadUrl) { this.downloadUrl = downloadUrl; }
        public boolean isRequired() { return required; }
        public void setRequired(boolean required) { this.required = required; }
    }
}
