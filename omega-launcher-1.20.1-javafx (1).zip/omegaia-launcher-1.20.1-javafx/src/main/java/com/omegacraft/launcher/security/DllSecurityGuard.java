package com.omegacraft.launcher.security;

import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * Модуль защиты от DLL-инъекций и прокси-библиотек в процессе запущенного Minecraft.
 * Работает без жёстких compile-time зависимостей: проверяет активные инжекторы через ProcessHandle
 * и сканирует загруженные в память DLL через Win32 Toolhelp32 (JNA Kernel32Util, если доступен).
 */
public final class DllSecurityGuard {
    private static final List<String> CHEAT_DLL_KEYWORDS = List.of(
            "vape", "drip", "entropy", "slinky", "doomsday", "wurst",
            "nursultan", "celestial", "expensive", "akrien", "minced",
            "wexside", "killaura", "aimbot", "autoclicker", "minhook",
            "cheatengine", "speedhack", "imgui", "extremeinjector", "processhacker",
            "xenos", "gh_injector"
    );

    private static final Set<String> PROXY_HIJACK_DLLS = Set.of(
            "version.dll", "winhttp.dll", "winmm.dll", "dinput8.dll", "dxgi.dll", "xinput1_3.dll", "dbghelp.dll"
    );

    private static volatile boolean jnaChecked = false;
    private static volatile Method getModulesMethod = null;
    private static volatile Method szModuleMethod = null;
    private static volatile Method szExePathMethod = null;

    private DllSecurityGuard() {}

    public static String scanProcessModules(long pid, Path gameDirectory) {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (!os.contains("win") || pid <= 0 || pid > Integer.MAX_VALUE) {
            return null;
        }

        // 1. Проверка активных процессов-инжекторов и чит-клиентов (чистый JDK 17)
        String injectorViolation = scanRunningInjectors(pid);
        if (injectorViolation != null) {
            return injectorViolation;
        }

        // 2. Снимок загруженных DLL внутри процесса Minecraft (Win32 Toolhelp32 через JNA Kernel32Util)
        ensureJnaReflectionReady();
        if (getModulesMethod == null || szModuleMethod == null || szExePathMethod == null) {
            return null;
        }

        String gameDirNorm = gameDirectory.toAbsolutePath().normalize().toString().toLowerCase(Locale.ROOT);
        String javaHome = System.getProperty("java.home", "").toLowerCase(Locale.ROOT);

        try {
            Object rawList = getModulesMethod.invoke(null, (int) pid);
            if (!(rawList instanceof List<?> modules)) {
                return null;
            }
            for (Object entry : modules) {
                if (entry == null) continue;
                String rawModName = String.valueOf(szModuleMethod.invoke(entry));
                String rawExePath = String.valueOf(szExePathMethod.invoke(entry));
                String modName = rawModName.toLowerCase(Locale.ROOT);
                String exePath = rawExePath.toLowerCase(Locale.ROOT);
                if (!modName.endsWith(".dll")) {
                    continue;
                }

                for (String kw : CHEAT_DLL_KEYWORDS) {
                    if (modName.contains(kw) || exePath.contains("\\" + kw)) {
                        return "Обнаружена инъекция чит-DLL: " + rawModName;
                    }
                }

                boolean isSystemWin = exePath.startsWith("c:\\windows\\")
                        || exePath.startsWith("\\systemroot\\");
                boolean isBundledJava = !javaHome.isBlank() && exePath.startsWith(javaHome);

                if (!isSystemWin && !isBundledJava && PROXY_HIJACK_DLLS.contains(modName)) {
                    return "Обнаружена прокси-подмена системной DLL: " + rawModName + " (" + rawExePath + ")";
                }

                if (!isBundledJava && exePath.startsWith(gameDirNorm) && !IntegrityVerifier.isAllowedGameNativeName(modName)) {
                    return "Сторонняя DLL в каталоге игры: " + rawModName;
                }

                boolean isHighRiskUserFolder = exePath.contains("\\desktop\\")
                        || exePath.contains("\\downloads\\")
                        || exePath.contains("\\documents\\")
                        || exePath.contains("\\appdata\\roaming\\")
                        || exePath.contains("\\appdata\\local\\temp\\");
                if (isHighRiskUserFolder && !isBundledJava && !IntegrityVerifier.isAllowedGameNativeName(modName)) {
                    return "Подозрительная пользовательская DLL в памяти игры: " + rawModName;
                }
            }
        } catch (Throwable ignored) {
            // Если процесс уже завершился в момент снимка Toolhelp32 — игнорируем
        }
        return null;
    }

    private static String scanRunningInjectors(long mcPid) {
        try {
            long selfPid = ProcessHandle.current().pid();
            for (ProcessHandle ph : ProcessHandle.allProcesses().toList()) {
                long p = ph.pid();
                if (p == selfPid || p == mcPid) continue;
                Optional<String> cmdOpt = ph.info().command();
                if (cmdOpt.isEmpty()) continue;
                String cmdLower = cmdOpt.get().toLowerCase(Locale.ROOT);
                for (String kw : CHEAT_DLL_KEYWORDS) {
                    if (kw.length() >= 4 && cmdLower.contains(kw)) {
                        Path fileName = Path.of(cmdOpt.get()).getFileName();
                        return "Обнаружен запущенный инжектор/чит-процесс: " + (fileName != null ? fileName : cmdOpt.get());
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private static void ensureJnaReflectionReady() {
        if (jnaChecked) return;
        synchronized (DllSecurityGuard.class) {
            if (jnaChecked) return;
            try {
                Class<?> kernel32UtilClass = Class.forName("com.sun.jna.platform.win32.Kernel32Util");
                Class<?> moduleEntryClass = Class.forName("com.sun.jna.platform.win32.Tlhelp32$MODULEENTRY32W");
                Method gm = kernel32UtilClass.getMethod("getModules", int.class);
                Method sm = moduleEntryClass.getMethod("szModule");
                Method se = moduleEntryClass.getMethod("szExePath");
                sm.setAccessible(true);
                se.setAccessible(true);
                getModulesMethod = gm;
                szModuleMethod = sm;
                szExePathMethod = se;
            } catch (Throwable ignored) {
                getModulesMethod = null;
            } finally {
                jnaChecked = true;
            }
        }
    }
}
