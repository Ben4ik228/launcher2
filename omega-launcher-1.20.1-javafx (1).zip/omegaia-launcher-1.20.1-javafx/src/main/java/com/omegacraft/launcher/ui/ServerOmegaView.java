package com.omegacraft.launcher.ui;

import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.SessionData;
import com.omegacraft.launcher.security.IntegrityVerifier;
import com.omegacraft.launcher.service.AutoUpdaterService;
import com.omegacraft.launcher.service.MinecraftLauncher;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.stage.Stage;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class ServerOmegaView {
    private final BorderPane root = new BorderPane();

    public ServerOmegaView(
            Stage stage,
            LauncherConfig config,
            SessionData session,
            Path gameDirectory,
            ThemeManager themeManager,
            IntegrityVerifier integrityVerifier,
            AutoUpdaterService updaterService,
            Runnable onLogout
    ) {
        root.getStyleClass().add("app-root");

        HBox titleBar = ThemeManager.createWindowBar(
                stage,
                "OmegaIA Launcher · " + session.getUsername(),
                themeManager,
                null
        );
        root.setTop(titleBar);

        // --- Left Sidebar (Server Card + Session Summary + Footer) ---
        VBox sidebar = new VBox();
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(258);
        sidebar.setMinWidth(258);
        sidebar.setMaxWidth(258);

        Label sectionTitle = new Label("Игровой сервер");
        sectionTitle.getStyleClass().add("sidebar-section-title");
        VBox.setMargin(sectionTitle, new Insets(16, 16, 10, 16));

        HBox activeServerRow = new HBox(12);
        activeServerRow.getStyleClass().add("server-item-active");
        activeServerRow.setAlignment(Pos.CENTER_LEFT);
        activeServerRow.setPadding(new Insets(12, 14, 12, 14));
        VBox.setMargin(activeServerRow, new Insets(0, 12, 0, 12));

        StackPane serverBadge = new StackPane(createMiniServerGlyph());
        serverBadge.getStyleClass().add("server-badge-box");
        serverBadge.setPrefSize(34, 34);
        serverBadge.setMinSize(34, 34);
        serverBadge.setMaxSize(34, 34);

        VBox serverNames = new VBox(2);
        HBox.setHgrow(serverNames, Priority.ALWAYS);
        Label serverNameLbl = new Label(config.getServerName());
        serverNameLbl.getStyleClass().add("server-name");
        Label loaderLbl = new Label(config.getMinecraftVersion() + " · " + config.getModLoader());
        loaderLbl.getStyleClass().add("server-loader");
        serverNames.getChildren().addAll(serverNameLbl, loaderLbl);

        HBox onlineBox = new HBox(5);
        onlineBox.setAlignment(Pos.CENTER_RIGHT);
        Region onlineDot = new Region();
        onlineDot.getStyleClass().add("online-dot");
        onlineDot.setPrefSize(7, 7);
        onlineDot.setMinSize(7, 7);
        onlineDot.setMaxSize(7, 7);
        Label onlineLbl = new Label("Онлайн");
        onlineLbl.getStyleClass().add("server-count");
        onlineBox.getChildren().addAll(onlineDot, onlineLbl);

        activeServerRow.getChildren().addAll(serverBadge, serverNames, onlineBox);

        // Structured factual session/server info rows
        VBox infoPanel = new VBox(0);
        infoPanel.getStyleClass().add("sidebar-info-panel");
        VBox.setMargin(infoPanel, new Insets(18, 16, 0, 16));
        infoPanel.getChildren().addAll(
                createInfoRow("Игрок", session.getUsername()),
                createInfoRow("Версия", config.getMinecraftVersion()),
                createInfoRow("Память", config.getRamMb() + " МБ"),
                createInfoRow("Адрес", config.getServerAddress())
        );

        Region sidebarSpacer = new Region();
        VBox.setVgrow(sidebarSpacer, Priority.ALWAYS);

        HBox sidebarFooter = new HBox(8);
        sidebarFooter.getStyleClass().add("sidebar-footer");
        sidebarFooter.setPrefHeight(52);
        sidebarFooter.setAlignment(Pos.CENTER_LEFT);
        sidebarFooter.setPadding(new Insets(0, 12, 0, 12));

        Button folderBtn = new Button("Папка");
        folderBtn.getStyleClass().add("sidebar-icon-btn");
        folderBtn.setGraphic(createIcon("M 2 3 L 7 3 L 9 5 L 14 5 L 14 13 L 2 13 Z"));
        folderBtn.setGraphicTextGap(7);
        folderBtn.setMinWidth(Region.USE_PREF_SIZE);
        folderBtn.setOnAction(e -> openGameFolder(gameDirectory));

        Region footerSpacer = new Region();
        HBox.setHgrow(footerSpacer, Priority.ALWAYS);

        Button logoutBtn = new Button("Выйти");
        logoutBtn.getStyleClass().add("sidebar-icon-btn");
        logoutBtn.setGraphic(createIcon("M 6 2 L 3 2 L 3 14 L 6 14 M 9 5 L 13 8 L 9 11 M 5 8 L 13 8"));
        logoutBtn.setGraphicTextGap(7);
        logoutBtn.setMinWidth(Region.USE_PREF_SIZE);
        logoutBtn.setOnAction(e -> onLogout.run());

        sidebarFooter.getChildren().addAll(folderBtn, footerSpacer, logoutBtn);
        sidebar.getChildren().addAll(sectionTitle, activeServerRow, infoPanel, sidebarSpacer, sidebarFooter);

        // --- Right Hero Pane (Full-bleed RPG Artwork + Title Overlay + Bottom Dock) ---
        StackPane heroPane = new StackPane();
        heroPane.getStyleClass().add("hero-pane");
        HBox.setHgrow(heroPane, Priority.ALWAYS);

        Pane artworkLayer = new Pane();
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(artworkLayer.widthProperty());
        clip.heightProperty().bind(artworkLayer.heightProperty());
        artworkLayer.setClip(clip);

        try (InputStream splashStream = ServerOmegaView.class.getResourceAsStream("/images/omega-splash.jpg")) {
            if (splashStream != null) {
                Image splashImg = new Image(splashStream);
                ImageView splashView = new ImageView(splashImg);
                splashView.setPreserveRatio(true);
                splashView.setSmooth(true);
                splashView.fitWidthProperty().bind(
                        Bindings.max(artworkLayer.widthProperty(), artworkLayer.heightProperty().multiply(16.0 / 9.0))
                );
                splashView.layoutXProperty().bind(
                        artworkLayer.widthProperty().subtract(splashView.fitWidthProperty()).divide(2)
                );
                artworkLayer.getChildren().add(splashView);
            }
        } catch (Exception ignored) {
        }

        Region scrim = new Region();
        scrim.getStyleClass().add("hero-scrim");
        scrim.setMouseTransparent(true);

        VBox bottomOverlay = new VBox(0);
        bottomOverlay.setAlignment(Pos.BOTTOM_LEFT);
        StackPane.setAlignment(bottomOverlay, Pos.BOTTOM_CENTER);

        VBox heroCaption = new VBox(4);
        heroCaption.setPadding(new Insets(0, 26, 16, 26));
        Label heroTitle = new Label(config.getServerName() + " · Minecraft " + config.getMinecraftVersion());
        heroTitle.getStyleClass().add("hero-title");
        Label heroSub = new Label("Автоматическая синхронизация клиента и мгновенный вход на сервер");
        heroSub.getStyleClass().add("hero-subtitle");
        heroCaption.getChildren().addAll(heroTitle, heroSub);

        // Bottom Launch Dock
        HBox launchBar = new HBox(20);
        launchBar.getStyleClass().add("launch-bar");
        launchBar.setAlignment(Pos.CENTER_LEFT);
        launchBar.setPadding(new Insets(16, 26, 18, 26));
        launchBar.setMaxHeight(Region.USE_PREF_SIZE);

        VBox statusBox = new VBox(9);
        HBox.setHgrow(statusBox, Priority.ALWAYS);

        Label statusLabel = new Label("Путешествуй по измерениям, сражайся с боссами и играй на сервере " + config.getServerName() + "!");
        statusLabel.getStyleClass().add("launch-status-text");
        statusLabel.setWrapText(true);

        ProgressBar progressBar = new ProgressBar(0);
        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setPrefHeight(7);

        statusBox.getChildren().addAll(statusLabel, progressBar);

        Button playBtn = new Button("Играть");
        playBtn.getStyleClass().add("play-button");
        SVGPath playIcon = new SVGPath();
        playIcon.setContent("M 2 1 L 12 7 L 2 13 Z");
        playIcon.getStyleClass().add("play-btn-icon");
        playBtn.setGraphic(playIcon);
        playBtn.setGraphicTextGap(10);
        playBtn.setMinWidth(164);
        playBtn.setPrefHeight(44);

        playBtn.setOnAction(e -> {
            playBtn.setDisable(true);
            statusLabel.getStyleClass().remove("error-text");

            Task<Integer> launchTask = new Task<>() {
                private String crashText;

                @Override
                protected Integer call() throws Exception {
                    AutoUpdaterService.UpdateOutcome outcome = updaterService.checkAndApplyUpdates((pct, msg) ->
                            Platform.runLater(() -> {
                                progressBar.setProgress(pct / 100.0);
                                statusLabel.setText(msg);
                            })
                    );
                    Platform.runLater(() -> statusLabel.setText(
                            "Обновлено модов: " + outcome.downloadedModsCount()
                                    + " · Запуск Minecraft " + config.getMinecraftVersion() + "..."
                    ));
                    MinecraftLauncher mc = new MinecraftLauncher(gameDirectory, config);
                    MinecraftLauncher.LaunchSession mcSession = mc.launch(session, outcome.verifiedMods());

                    Platform.runLater(stage::hide);

                    int exitCode = mc.waitForExit(mcSession);
                    if (exitCode != 0) {
                        this.crashText = mc.extractCrashMessage(mcSession, exitCode);
                    }
                    return exitCode;
                }

                @Override
                protected void succeeded() {
                    restoreStage(stage);
                    playBtn.setDisable(false);
                    progressBar.setProgress(0);
                    int code = getValue() != null ? getValue() : 0;
                    if (code == 0) {
                        statusLabel.getStyleClass().remove("error-text");
                        statusLabel.setText("Этот сеанс был закрыт");
                    } else {
                        if (!statusLabel.getStyleClass().contains("error-text")) {
                            statusLabel.getStyleClass().add("error-text");
                        }
                        statusLabel.setText("Этот сеанс был закрыт — " + (crashText != null ? crashText : "см. logs/latest.log"));
                    }
                }

                @Override
                protected void failed() {
                    restoreStage(stage);
                    playBtn.setDisable(false);
                    progressBar.setProgress(0);
                    Throwable ex = getException();
                    String msg = ex != null ? ex.getMessage() : "Неизвестная ошибка";
                    if (!statusLabel.getStyleClass().contains("error-text")) {
                        statusLabel.getStyleClass().add("error-text");
                    }
                    statusLabel.setText("Ошибка запуска: " + msg);
                }
            };
            new Thread(launchTask, "OmegaIA-Launch-Worker").start();
        });

        launchBar.getChildren().addAll(statusBox, playBtn);
        bottomOverlay.getChildren().addAll(heroCaption, launchBar);

        heroPane.getChildren().addAll(artworkLayer, scrim, bottomOverlay);

        HBox mainSplit = new HBox(sidebar, heroPane);
        root.setCenter(mainSplit);
    }

    private static Label createMiniServerGlyph() {
        Label glyph = new Label("Ω");
        glyph.getStyleClass().add("server-glyph");
        return glyph;
    }

    private static HBox createInfoRow(String label, String value) {
        HBox row = new HBox(8);
        row.getStyleClass().add("sidebar-info-row");
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(9, 0, 9, 0));

        Label keyLbl = new Label(label);
        keyLbl.getStyleClass().add("sidebar-info-key");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        Label valLbl = new Label(value == null ? "" : value);
        valLbl.getStyleClass().add("sidebar-info-val");

        row.getChildren().addAll(keyLbl, spacer, valLbl);
        return row;
    }

    private static SVGPath createIcon(String pathData) {
        SVGPath svg = ThemeManager.createSvgStroke(pathData, 0.92);
        svg.getStyleClass().add("sidebar-btn-icon");
        return svg;
    }

    private static void restoreStage(Stage stage) {
        if (!stage.isShowing()) {
            stage.show();
        }
        stage.setIconified(false);
        stage.toFront();
        stage.requestFocus();
    }

    private void openGameFolder(Path gameDirectory) {
        try {
            Files.createDirectories(gameDirectory);
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                new ProcessBuilder("explorer.exe", gameDirectory.toAbsolutePath().toString()).start();
            } else if (os.contains("mac")) {
                new ProcessBuilder("open", gameDirectory.toAbsolutePath().toString()).start();
            } else {
                new ProcessBuilder("xdg-open", gameDirectory.toAbsolutePath().toString()).start();
            }
        } catch (Exception ignored) {
        }
    }

    public Parent getRoot() {
        return root;
    }
}
