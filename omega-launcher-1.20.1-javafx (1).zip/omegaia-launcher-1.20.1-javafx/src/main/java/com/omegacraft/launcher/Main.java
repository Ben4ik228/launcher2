package com.omegacraft.launcher;

/**
 * Обёртка точки входа для запуска shaded fat-JAR (mvn clean package -> java -jar)
 * без ошибки "JavaFX runtime components are missing".
 */
public class Main {
    public static void main(String[] args) {
        LauncherApp.main(args);
    }
}
