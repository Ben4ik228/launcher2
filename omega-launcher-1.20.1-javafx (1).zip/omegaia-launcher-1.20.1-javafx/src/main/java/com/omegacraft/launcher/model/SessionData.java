package com.omegacraft.launcher.model;

public class SessionData {
    private String username;
    private String uuid;
    private String accessToken;
    private long expiresAtEpochMs;

    public SessionData() {}

    public SessionData(String username, String uuid, String accessToken, long expiresAtEpochMs) {
        this.username = username;
        this.uuid = uuid;
        this.accessToken = accessToken;
        this.expiresAtEpochMs = expiresAtEpochMs;
    }

    public String getUsername() { return username; }
    public String getUuid() { return uuid; }
    public String getAccessToken() { return accessToken; }
    public long getExpiresAtEpochMs() { return expiresAtEpochMs; }

    public boolean isValid() {
        return username != null && !username.isBlank()
                && accessToken != null && !accessToken.isBlank()
                && System.currentTimeMillis() < expiresAtEpochMs;
    }
}
