package com.omegacraft.launcher.ui;

import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.SessionData;
import com.omegacraft.launcher.service.AuthService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.InputStream;
import java.util.function.Consumer;

public class LoginView {
    private final VBox root = new VBox();

    public LoginView(
            Stage stage,
            LauncherConfig config,
            AuthService authService,
            ThemeManager themeManager,
            Consumer<SessionData> onAuthenticated
    ) {
        root.getStyleClass().add("app-root");

        HBox titleBar = ThemeManager.createWindowBar(
                stage,
                "OmegaIA Launcher — Авторизация",
                themeManager,
                null
        );

        VBox content = new VBox(14);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(26, 40, 32, 40));
        VBox.setVgrow(content, Priority.ALWAYS);

        Node logoNode = createLogoBadge();

        VBox headerBox = new VBox(4);
        headerBox.setAlignment(Pos.CENTER);
        Label title = new Label("OmegaIA");
        title.getStyleClass().add("heading-xl");
        Label subtitle = new Label("Вход в игровой аккаунт");
        subtitle.getStyleClass().add("muted-text");
        headerBox.getChildren().addAll(title, subtitle);

        VBox formCard = new VBox(12);
        formCard.getStyleClass().add("login-card");
        formCard.setPadding(new Insets(18));

        VBox userGroup = new VBox(5);
        Label userLbl = new Label("Никнейм");
        userLbl.getStyleClass().add("field-label");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Введите игровой ник");
        usernameField.setPrefHeight(42);
        usernameField.getStyleClass().add("launcher-input");
        userGroup.getChildren().addAll(userLbl, usernameField);

        VBox passGroup = new VBox(5);
        Label passLbl = new Label("Пароль");
        passLbl.getStyleClass().add("field-label");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Пароль доступа");
        passwordField.setPrefHeight(42);
        passwordField.getStyleClass().add("launcher-input");
        passGroup.getChildren().addAll(passLbl, passwordField);

        CheckBox rememberCheck = new CheckBox("Входить автоматически");
        rememberCheck.setSelected(true);
        rememberCheck.setMaxWidth(Double.MAX_VALUE);
        rememberCheck.getStyleClass().add("launcher-checkbox");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-text");
        errorLabel.setWrapText(true);
        errorLabel.setMaxWidth(Double.MAX_VALUE);
        errorLabel.setVisible(false);
        errorLabel.managedProperty().bind(errorLabel.visibleProperty());

        Button fillTestBtn = new Button("Тест-пароль");
        fillTestBtn.getStyleClass().add("secondary-button");
        fillTestBtn.setPrefHeight(42);
        fillTestBtn.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(fillTestBtn, Priority.ALWAYS);
        fillTestBtn.setOnAction(e -> {
            if (usernameField.getText().isBlank()) {
                usernameField.setText("Steve_OmegaIA");
            }
            passwordField.setText(config.getTestPassword());
            errorLabel.setVisible(false);
        });

        Button loginBtn = new Button("Войти");
        loginBtn.getStyleClass().add("primary-button");
        loginBtn.setPrefHeight(42);
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(loginBtn, Priority.ALWAYS);

        Runnable submit = () -> {
            AuthService.AuthResult result = authService.login(
                    usernameField.getText(),
                    passwordField.getText(),
                    rememberCheck.isSelected()
            );
            if (result.ok()) {
                onAuthenticated.accept(result.session());
            } else {
                errorLabel.setText(result.error());
                errorLabel.setVisible(true);
            }
        };

        loginBtn.setOnAction(e -> submit.run());
        usernameField.setOnAction(e -> submit.run());
        passwordField.setOnAction(e -> submit.run());

        HBox buttonsRow = new HBox(10, fillTestBtn, loginBtn);
        buttonsRow.setAlignment(Pos.CENTER);
        buttonsRow.setPadding(new Insets(4, 0, 0, 0));

        formCard.getChildren().addAll(
                userGroup,
                passGroup,
                rememberCheck,
                errorLabel,
                buttonsRow
        );

        content.getChildren().addAll(logoNode, headerBox, formCard);
        root.getChildren().addAll(titleBar, content);
    }

    private Node createLogoBadge() {
        try (InputStream stream = LoginView.class.getResourceAsStream("/images/omega-logo.jpg")) {
            if (stream != null) {
                Image img = new Image(stream);
                ImageView view = new ImageView(img);
                view.setFitWidth(76);
                view.setFitHeight(76);
                view.setPreserveRatio(true);
                view.setSmooth(true);

                Rectangle clip = new Rectangle(76, 76);
                clip.setArcWidth(22);
                clip.setArcHeight(22);
                view.setClip(clip);
                return view;
            }
        } catch (Exception ignored) {
        }

        StackPane fallback = new StackPane(new Label("Ω"));
        fallback.setPrefSize(76, 76);
        fallback.setMaxSize(76, 76);
        fallback.getStyleClass().add("logo-badge-fallback");
        return fallback;
    }

    public Parent getRoot() {
        return root;
    }
}
