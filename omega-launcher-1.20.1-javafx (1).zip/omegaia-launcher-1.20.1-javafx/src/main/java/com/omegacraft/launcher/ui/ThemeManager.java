package com.omegacraft.launcher.ui;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Stage;

import java.io.InputStream;

public class ThemeManager {
    private final Scene scene;
    private String activeTheme;

    public ThemeManager(Scene scene, String initialTheme) {
        this.scene = scene;
        this.activeTheme = "obsidian";
    }

    public void applyTheme(String themeId) {
        this.activeTheme = "obsidian";
        scene.getStylesheets().clear();
        var url = getClass().getResource("/styles/theme-obsidian.css");
        if (url != null) {
            scene.getStylesheets().add(url.toExternalForm());
        }
    }

    public String getActiveTheme() {
        return activeTheme;
    }

    public static HBox createWindowBar(
            Stage stage,
            String titleText,
            ThemeManager themeManager,
            Runnable onToggleSettings
    ) {
        HBox bar = new HBox(10);
        bar.getStyleClass().add("window-titlebar");
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPrefHeight(36);
        bar.setMinHeight(36);
        bar.setPadding(new Insets(0, 0, 0, 14));

        try (InputStream iconStream = ThemeManager.class.getResourceAsStream("/images/omega-logo.jpg")) {
            if (iconStream != null) {
                ImageView miniLogo = new ImageView(new Image(iconStream));
                miniLogo.setFitWidth(18);
                miniLogo.setFitHeight(18);
                miniLogo.setPreserveRatio(true);
                miniLogo.setSmooth(true);
                Rectangle clip = new Rectangle(18, 18);
                clip.setArcWidth(5);
                clip.setArcHeight(5);
                miniLogo.setClip(clip);
                bar.getChildren().add(miniLogo);
            }
        } catch (Exception ignored) {
        }

        Label title = new Label(titleText);
        title.getStyleClass().add("window-title-text");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        bar.getChildren().addAll(title, spacer);

        Button minBtn = createChromeButton(
                createSvgStroke("M 1 6 L 11 6", 1.0),
                "titlebar-btn",
                "Свернуть"
        );
        minBtn.setOnAction(e -> stage.setIconified(true));

        Button closeBtn = createChromeButton(
                createSvgStroke("M 1 1 L 10 10 M 10 1 L 1 10", 1.0),
                "titlebar-close-btn",
                "Закрыть"
        );
        closeBtn.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });

        bar.getChildren().addAll(minBtn, closeBtn);

        final double[] offset = new double[2];
        bar.setOnMousePressed(e -> {
            offset[0] = e.getSceneX();
            offset[1] = e.getSceneY();
        });
        bar.setOnMouseDragged(e -> {
            stage.setX(e.getScreenX() - offset[0]);
            stage.setY(e.getScreenY() - offset[1]);
        });

        return bar;
    }

    private static Button createChromeButton(SVGPath icon, String styleClass, String tooltipText) {
        Button btn = new Button();
        btn.setGraphic(icon);
        btn.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        btn.getStyleClass().add(styleClass);
        btn.setMinSize(40, 36);
        btn.setPrefSize(40, 36);
        btn.setMaxSize(40, 36);
        btn.setFocusTraversable(false);
        btn.setTooltip(new Tooltip(tooltipText));
        return btn;
    }

    public static SVGPath createSvgStroke(String pathData, double scale) {
        SVGPath svg = new SVGPath();
        svg.setContent(pathData);
        svg.setScaleX(scale);
        svg.setScaleY(scale);
        svg.setStrokeLineCap(StrokeLineCap.ROUND);
        svg.getStyleClass().add("titlebar-icon");
        return svg;
    }
}
