package com.omegacraft.launcher.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class LauncherConfig {
    private String serverName = "OmegaIA";
    private String serverAddress = "play.omega-craft.ru";
    private int serverPort = 25565;
    private String minecraftVersion = "1.20.1";
    private String modLoader = "Forge 47.3.0";
    private String forgeVersion = "47.3.0";
    private String modpackUrl = "https://github.com/Ben4ik228/launcher/archive/refs/heads/main.zip";
    private String optionsTxtUrl = "https://raw.githubusercontent.com/Ben4ik228/launcher/main/options.txt";
    private String optionsOfUrl = "https://raw.githubusercontent.com/Ben4ik228/launcher/main/optionsof.txt";
    private String clientArchiveUrl = "";
    private String clientVersion = "1.20.1-build.42";
    private String launcherVersion = "2.4.0";
    private String testPassword = "omega2026";
    private String defaultTheme = "obsidian";
    private int ramMb = 4096;
    private boolean strictAntiCheat = true;
    private boolean autoUpdateEnabled = true;
    private String expectedLauncherSha256 = "";

    public static LauncherConfig load() {
        Gson gson = new GsonBuilder().create();
        try (InputStream is = LauncherConfig.class.getResourceAsStream("/launcher-config.json")) {
            if (is != null) {
                LauncherConfig loaded = gson.fromJson(new InputStreamReader(is, StandardCharsets.UTF_8), LauncherConfig.class);
                if (loaded != null) {
                    return loaded;
                }
            }
        } catch (Exception ignored) {
        }
        return new LauncherConfig();
    }

    public String getServerName() { return serverName; }
    public String getServerAddress() { return serverAddress; }
    public int getServerPort() { return serverPort; }
    public String getMinecraftVersion() { return minecraftVersion; }
    public String getModLoader() { return modLoader; }
    public String getForgeVersion() {
        if (forgeVersion != null && !forgeVersion.isBlank()) {
            return forgeVersion;
        }
        if (modLoader != null && modLoader.toLowerCase().contains("forge")) {
            String digits = modLoader.replaceAll("[^0-9.]", "");
            if (!digits.isBlank()) return digits;
        }
        return "47.3.0";
    }
    public String getModpackUrl() { return modpackUrl; }
    public void setModpackUrl(String modpackUrl) { this.modpackUrl = modpackUrl; }
    public String getOptionsTxtUrl() { return optionsTxtUrl == null ? "" : optionsTxtUrl; }
    public void setOptionsTxtUrl(String optionsTxtUrl) { this.optionsTxtUrl = optionsTxtUrl; }
    public String getOptionsOfUrl() { return optionsOfUrl == null ? "" : optionsOfUrl; }
    public void setOptionsOfUrl(String optionsOfUrl) { this.optionsOfUrl = optionsOfUrl; }
    public String getClientArchiveUrl() { return clientArchiveUrl == null ? "" : clientArchiveUrl; }
    public void setClientArchiveUrl(String clientArchiveUrl) { this.clientArchiveUrl = clientArchiveUrl; }
    public String getClientVersion() { return clientVersion; }
    public String getLauncherVersion() { return launcherVersion; }
    public String getTestPassword() { return testPassword; }
    public String getDefaultTheme() { return defaultTheme; }
    public int getRamMb() { return ramMb; }
    public boolean isStrictAntiCheat() { return strictAntiCheat; }
    public boolean isAutoUpdateEnabled() { return autoUpdateEnabled; }
    public String getExpectedLauncherSha256() { return expectedLauncherSha256; }
}
