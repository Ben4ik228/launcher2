package com.omegacraft.launcher.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.omegacraft.launcher.model.ModManifest;
import com.omegacraft.launcher.security.IntegrityVerifier;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Загружает моды (GitHub-репозиторий, .zip архив или JSON-манифест),
 * а также файлы конфигурации options.txt и optionsof.txt.
 */
public class ModSyncService {
    private static final Pattern GITHUB_BLOB_PATTERN = Pattern.compile(
            "^https?://github\\.com/([^/]+)/([^/]+)/blob/([^?#]+)(?:\\?raw=true)?$",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern GITHUB_REPO_PATTERN = Pattern.compile(
            "^https?://github\\.com/([^/]+)/([^/]+?)(?:\\.git)?/?$",
            Pattern.CASE_INSENSITIVE
    );

    private final OkHttpClient http = new OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .followRedirects(true)
            .build();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path gameDirectory;

    public ModSyncService(Path gameDirectory) {
        this.gameDirectory = gameDirectory;
    }

    public static String normalizeDirectUrl(String rawUrl) {
        if (rawUrl == null) return "";
        String trimmed = rawUrl.trim();
        if (trimmed.isEmpty()) return "";
        Matcher blob = GITHUB_BLOB_PATTERN.matcher(trimmed);
        if (blob.matches()) {
            return "https://raw.githubusercontent.com/" + blob.group(1) + "/" + blob.group(2) + "/" + blob.group(3);
        }
        Matcher repo = GITHUB_REPO_PATTERN.matcher(trimmed);
        if (repo.matches()) {
            return "https://github.com/" + repo.group(1) + "/" + repo.group(2) + "/archive/refs/heads/main.zip";
        }
        return trimmed;
    }

    public String fetchRemoteEtag(String url) {
        String directUrl = normalizeDirectUrl(url);
        if (directUrl.isBlank()) return "";
        Request headReq = new Request.Builder().url(directUrl).head().build();
        try (Response response = http.newCall(headReq).execute()) {
            if (response.isSuccessful()) {
                String etag = response.header("ETag");
                return etag == null ? "" : etag.replace("\"", "").trim();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    public ModManifest fetchManifest(String url) throws IOException {
        String directUrl = normalizeDirectUrl(url);
        Request request = new Request.Builder().url(directUrl).get().build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                throw new IOException("Ошибка загрузки манифеста HTTP " + response.code());
            }
            String body = response.body().string();
            ModManifest manifest = gson.fromJson(body, ModManifest.class);
            if (manifest == null || manifest.getMods() == null) {
                throw new IOException("Неверный формат манифеста модов.");
            }
            return manifest;
        }
    }

    public void downloadMissingMods(
            List<ModManifest.ModItem> mods,
            BiConsumer<Integer, String> progressCallback
    ) throws IOException {
        Path modsDir = gameDirectory.resolve("mods");
        Files.createDirectories(modsDir);

        int total = Math.max(1, mods.size());
        for (int i = 0; i < mods.size(); i++) {
            ModManifest.ModItem mod = mods.get(i);
            int pct = 65 + (i * 25) / total;
            progressCallback.accept(pct, "Скачивание мода: " + mod.getName());

            Path target = modsDir.resolve(mod.getFileName());
            Path temp = modsDir.resolve(mod.getFileName() + ".part");
            downloadFile(normalizeDirectUrl(mod.getDownloadUrl()), temp);

            String actualHash = IntegrityVerifier.computeSha256(temp);
            if (mod.getSha256() != null && !mod.getSha256().isBlank()
                    && !actualHash.equalsIgnoreCase(mod.getSha256())) {
                Files.deleteIfExists(temp);
                throw new IOException("SHA-256 не совпадает для мода: " + mod.getFileName());
            }
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        }
        progressCallback.accept(90, "Все моды проверены и готовы.");
    }

    public ZipSyncResult syncFromZipArchive(
            String zipUrl,
            boolean strictAntiCheat,
            BiConsumer<Integer, String> progressCallback
    ) throws IOException {
        Path modsDir = gameDirectory.resolve("mods");
        Path quarantineDir = gameDirectory.resolve("quarantine");
        Files.createDirectories(modsDir);
        Files.createDirectories(quarantineDir);
        Path tempZip = gameDirectory.resolve("modpack-sync.zip");

        progressCallback.accept(68, "Загрузка файлов и модов...");
        String directZip = normalizeDirectUrl(zipUrl);
        try {
            downloadFile(directZip, tempZip);
        } catch (IOException ex) {
            if (directZip.endsWith("/archive/refs/heads/main.zip")) {
                String masterZip = directZip.substring(0, directZip.length() - "main.zip".length()) + "master.zip";
                downloadFile(masterZip, tempZip);
            } else {
                throw ex;
            }
        }

        Set<String> allowedJarNames = new HashSet<>();
        List<ModManifest.ModItem> syncedItems = new ArrayList<>();
        boolean unpackedOptions = false;
        boolean unpackedOptionsOf = false;

        progressCallback.accept(80, "Распаковка модов и настроек...");
        try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(tempZip))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String rawName = entry.getName().replace('\\', '/');
                String baseName = Paths.get(rawName).getFileName().toString();
                String lower = baseName.toLowerCase(Locale.ROOT);

                if (lower.equals("options.txt")) {
                    Path optOut = gameDirectory.resolve("options.txt").normalize();
                    if (optOut.startsWith(gameDirectory)) {
                        Files.copy(zis, optOut, StandardCopyOption.REPLACE_EXISTING);
                        unpackedOptions = true;
                    }
                    continue;
                }
                if (lower.equals("optionsof.txt")) {
                    Path optOfOut = gameDirectory.resolve("optionsof.txt").normalize();
                    if (optOfOut.startsWith(gameDirectory)) {
                        Files.copy(zis, optOfOut, StandardCopyOption.REPLACE_EXISTING);
                        unpackedOptionsOf = true;
                    }
                    continue;
                }

                if (!lower.endsWith(".jar")) continue;
                boolean inModsFolder = rawName.toLowerCase(Locale.ROOT).contains("/mods/")
                        || rawName.toLowerCase(Locale.ROOT).startsWith("mods/")
                        || !rawName.contains("/");
                if (!inModsFolder) continue;

                Path out = modsDir.resolve(baseName).normalize();
                if (!out.startsWith(modsDir)) continue; // Защита от Zip Slip
                Files.copy(zis, out, StandardCopyOption.REPLACE_EXISTING);
                allowedJarNames.add(lower);

                String sha = IntegrityVerifier.computeSha256(out);
                ModManifest.ModItem item = new ModManifest.ModItem();
                item.setFileName(baseName);
                item.setName(baseName.replaceFirst("\\.jar$", ""));
                item.setSha256(sha);
                item.setSizeBytes(Files.size(out));
                syncedItems.add(item);
            }
        } finally {
            Files.deleteIfExists(tempZip);
        }

        int removedCheats = 0;
        if (strictAntiCheat && !allowedJarNames.isEmpty()) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(modsDir)) {
                for (Path file : stream) {
                    String nameLower = file.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (Files.isDirectory(file) || !allowedJarNames.contains(nameLower)) {
                        Path qTarget = quarantineDir.resolve(System.currentTimeMillis() + "_" + file.getFileName());
                        Files.move(file, qTarget, StandardCopyOption.REPLACE_EXISTING);
                        removedCheats++;
                    }
                }
            }
        }

        ModManifest snapshot = new ModManifest();
        snapshot.setMods(syncedItems);
        Files.writeString(
                gameDirectory.resolve("synced-manifest.json"),
                gson.toJson(snapshot),
                StandardCharsets.UTF_8
        );

        progressCallback.accept(90, "Моды и настройки синхронизированы.");
        return new ZipSyncResult(syncedItems.size(), removedCheats, unpackedOptions, unpackedOptionsOf, syncedItems);
    }

    public ModManifest readSavedSyncedManifest() {
        Path file = gameDirectory.resolve("synced-manifest.json");
        if (!Files.exists(file)) return null;
        try {
            return gson.fromJson(Files.readString(file, StandardCharsets.UTF_8), ModManifest.class);
        } catch (Exception e) {
            return null;
        }
    }

    public void syncOptionsFiles(
            String optionsTxtUrl,
            String optionsOfUrl,
            BiConsumer<Integer, String> progressCallback
    ) throws IOException {
        Files.createDirectories(gameDirectory);
        String cleanOptions = normalizeDirectUrl(optionsTxtUrl);
        if (!cleanOptions.isBlank()) {
            progressCallback.accept(93, "Загрузка настроек игры (options.txt)...");
            downloadFile(cleanOptions, gameDirectory.resolve("options.txt"));
        }

        String cleanOptionsOf = normalizeDirectUrl(optionsOfUrl);
        if (!cleanOptionsOf.isBlank()) {
            progressCallback.accept(97, "Загрузка настроек графики (optionsof.txt)...");
            downloadFile(cleanOptionsOf, gameDirectory.resolve("optionsof.txt"));
        }
    }

    private void downloadFile(String url, Path dest) throws IOException {
        Files.createDirectories(dest.getParent());
        Request request = new Request.Builder().url(url).get().build();
        try (Response response = http.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) {
                throw new IOException("Не удалось скачать файл: " + url + " (HTTP " + response.code() + ")");
            }
            try (InputStream in = response.body().byteStream();
                 OutputStream out = Files.newOutputStream(dest)) {
                in.transferTo(out);
            }
        }
    }

    public record ZipSyncResult(
            int syncedModsCount,
            int quarantinedCount,
            boolean unpackedOptions,
            boolean unpackedOptionsOf,
            List<ModManifest.ModItem> syncedMods
    ) {}
}
