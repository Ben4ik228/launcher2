package com.omegacraft.launcher.service;

import com.google.gson.Gson;
import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.ModManifest;
import com.omegacraft.launcher.security.IntegrityVerifier;
import org.apache.commons.codec.digest.DigestUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Единый пайплайн подготовки клиента:
 * 1) Автоматическая установка Minecraft 1.20.1 + Forge 47.3.0 (Mojang + Forge Maven)
 * 2) Синхронизация и античит-проверка модов (GitHub-репозиторий, .zip или .json)
 * 3) Проверка нативных DLL и обязательного наличия всех модов сборки
 */
public class AutoUpdaterService {
    private final Path gameDirectory;
    private final Path stateFile;
    private final LauncherConfig config;
    private final IntegrityVerifier integrityVerifier;
    private final ModSyncService modSyncService;
    private final ClientInstallerService clientInstallerService;
    private final Gson gson = new Gson();

    public AutoUpdaterService(Path gameDirectory, LauncherConfig config, IntegrityVerifier integrityVerifier) {
        this.gameDirectory = gameDirectory;
        this.stateFile = gameDirectory.resolve("client-state.json");
        this.config = config;
        this.integrityVerifier = integrityVerifier;
        this.modSyncService = new ModSyncService(gameDirectory);
        this.clientInstallerService = new ClientInstallerService(gameDirectory, config);
    }

    public UpdateOutcome checkAndApplyUpdates(BiConsumer<Integer, String> progress) throws IOException {
        progress.accept(2, "Проверка установленного клиента 1.20.1 Forge...");
        clientInstallerService.ensureClientInstalled(progress);

        progress.accept(64, "Проверка обновлений модов и защиты DLL...");
        int blockedNativeDlls = integrityVerifier.sanitizeNativeLibraries(config.getMinecraftVersion());
        String cleanUrl = ModSyncService.normalizeDirectUrl(config.getModpackUrl());
        LocalClientState localState = readLocalState();

        if (cleanUrl.toLowerCase().endsWith(".zip")) {
            String remoteEtag = modSyncService.fetchRemoteEtag(cleanUrl);
            ModManifest savedManifest = modSyncService.readSavedSyncedManifest();

            String currentManifestSeal = computeManifestSeal();
            boolean etagMatches = localState != null
                    && remoteEtag != null && !remoteEtag.isBlank()
                    && remoteEtag.equals(localState.remoteEtag())
                    && localState.manifestSeal() != null && !localState.manifestSeal().isBlank()
                    && localState.manifestSeal().equals(currentManifestSeal)
                    && savedManifest != null
                    && savedManifest.getMods() != null
                    && !savedManifest.getMods().isEmpty();

            if (etagMatches) {
                progress.accept(78, "Сборка актуальна · Античит-проверка SHA-256 папки mods/...");
                IntegrityVerifier.ModAuditReport audit = integrityVerifier.sanitizeAndAuditMods(savedManifest);
                if (audit.modsToDownload().isEmpty()) {
                    if (!Files.exists(gameDirectory.resolve("options.txt")) || !Files.exists(gameDirectory.resolve("optionsof.txt"))) {
                        modSyncService.syncOptionsFiles(config.getOptionsTxtUrl(), config.getOptionsOfUrl(), progress);
                    }
                    integrityVerifier.assertAllRequiredModsPresent(savedManifest.getMods());
                    progress.accept(100, "Клиент и моды готовы к запуску.");
                    return new UpdateOutcome(
                            false,
                            config.getClientVersion(),
                            audit.quarantinedFiles().size() + blockedNativeDlls,
                            0,
                            savedManifest.getMods()
                    );
                }
            }

            ModSyncService.ZipSyncResult zipResult = modSyncService.syncFromZipArchive(cleanUrl, config.isStrictAntiCheat(), progress);
            if (!zipResult.unpackedOptions() || !zipResult.unpackedOptionsOf()) {
                modSyncService.syncOptionsFiles(
                        zipResult.unpackedOptions() ? "" : config.getOptionsTxtUrl(),
                        zipResult.unpackedOptionsOf() ? "" : config.getOptionsOfUrl(),
                        progress
                );
            }
            integrityVerifier.assertAllRequiredModsPresent(zipResult.syncedMods());
            writeLocalState(new LocalClientState(config.getClientVersion(), config.getLauncherVersion(), remoteEtag, computeManifestSeal()));
            progress.accept(100, "Клиент, моды и настройки готовы.");
            return new UpdateOutcome(
                    true,
                    config.getClientVersion(),
                    zipResult.quarantinedCount() + blockedNativeDlls,
                    zipResult.syncedModsCount(),
                    zipResult.syncedMods()
            );
        }

        ModManifest remote = modSyncService.fetchManifest(cleanUrl);
        boolean versionChanged = localState == null
                || (remote.getClientVersion() != null && !remote.getClientVersion().equals(localState.clientVersion()));

        progress.accept(72, "Проверка античитом и сверка SHA-256...");
        IntegrityVerifier.ModAuditReport audit = integrityVerifier.sanitizeAndAuditMods(remote);

        if (!audit.modsToDownload().isEmpty() || versionChanged) {
            modSyncService.downloadMissingMods(audit.modsToDownload(), progress);
            writeLocalState(new LocalClientState(remote.getClientVersion(), remote.getLauncherVersion(), "", ""));
        }

        integrityVerifier.assertAllRequiredModsPresent(remote.getMods());

        String effectiveOptionsTxt = firstNonBlank(remote.getOptionsTxtUrl(), config.getOptionsTxtUrl());
        String effectiveOptionsOf = firstNonBlank(remote.getOptionsOfUrl(), config.getOptionsOfUrl());
        modSyncService.syncOptionsFiles(effectiveOptionsTxt, effectiveOptionsOf, progress);

        progress.accept(100, "Клиент актуален. Все файлы проверены.");
        return new UpdateOutcome(
                !audit.modsToDownload().isEmpty() || versionChanged,
                remote.getClientVersion(),
                audit.quarantinedFiles().size() + blockedNativeDlls,
                audit.modsToDownload().size(),
                remote.getMods()
        );
    }

    private static String firstNonBlank(String primary, String fallback) {
        if (primary != null && !primary.isBlank()) return primary;
        return fallback == null ? "" : fallback;
    }

    private LocalClientState readLocalState() {
        if (!Files.exists(stateFile)) return null;
        try {
            return gson.fromJson(Files.readString(stateFile, StandardCharsets.UTF_8), LocalClientState.class);
        } catch (Exception e) {
            return null;
        }
    }

    private void writeLocalState(LocalClientState state) throws IOException {
        Files.createDirectories(stateFile.getParent());
        Files.writeString(stateFile, gson.toJson(state), StandardCharsets.UTF_8);
    }

    private String computeManifestSeal() {
        Path manifestFile = gameDirectory.resolve("synced-manifest.json");
        if (!Files.exists(manifestFile)) return "";
        try {
            String fileSha = IntegrityVerifier.computeSha256(manifestFile);
            return DigestUtils.sha256Hex("OmegaSeal:" + config.getClientVersion() + ":" + fileSha);
        } catch (Exception e) {
            return "";
        }
    }

    private record LocalClientState(String clientVersion, String launcherVersion, String remoteEtag, String manifestSeal) {}
    public record UpdateOutcome(
            boolean updated,
            String activeClientVersion,
            int blockedCheatsCount,
            int downloadedModsCount,
            List<ModManifest.ModItem> verifiedMods
    ) {}
}
