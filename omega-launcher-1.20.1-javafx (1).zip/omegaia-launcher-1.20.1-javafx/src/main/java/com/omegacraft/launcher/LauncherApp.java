package com.omegacraft.launcher;

import com.omegacraft.launcher.model.LauncherConfig;
import com.omegacraft.launcher.model.SessionData;
import com.omegacraft.launcher.security.IntegrityVerifier;
import com.omegacraft.launcher.service.AuthService;
import com.omegacraft.launcher.service.AutoUpdaterService;
import com.omegacraft.launcher.ui.LoginView;
import com.omegacraft.launcher.ui.ServerOmegaView;
import com.omegacraft.launcher.ui.ThemeManager;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

public class LauncherApp extends Application {
    private Stage primaryStage;
    private StackPane rootContainer;
    private LauncherConfig config;
    private Path gameDirectory;
    private AuthService authService;
    private ThemeManager themeManager;
    private IntegrityVerifier integrityVerifier;
    private AutoUpdaterService updaterService;

    @Override
    public void start(Stage stage) {
        Platform.setImplicitExit(false);
        this.primaryStage = stage;
        this.config = LauncherConfig.load();
        this.gameDirectory = resolveGameDirectory();
        this.authService = new AuthService(gameDirectory, config);
        this.integrityVerifier = new IntegrityVerifier(gameDirectory, config);
        this.updaterService = new AutoUpdaterService(gameDirectory, config, integrityVerifier);

        // Self-integrity check of the launcher JAR at startup
        IntegrityVerifier.SelfCheckResult selfCheck = integrityVerifier.verifyLauncherBinary();
        if (!selfCheck.valid() && config.isStrictAntiCheat()) {
            System.err.println("Нарушена целостность лаунчера: " + selfCheck.reason());
        }

        this.rootContainer = new StackPane();
        Scene scene = new Scene(rootContainer, 400, 500);
        this.themeManager = new ThemeManager(scene, "obsidian");
        this.themeManager.applyTheme("obsidian");

        stage.initStyle(StageStyle.UNDECORATED);
        stage.setResizable(false);
        stage.setTitle("OmegaIA Launcher — Minecraft " + config.getMinecraftVersion());
        try (InputStream iconStream = LauncherApp.class.getResourceAsStream("/images/omega-logo.jpg")) {
            if (iconStream != null) {
                stage.getIcons().add(new Image(iconStream));
            }
        } catch (Exception ignored) {
        }
        stage.setScene(scene);

        // Auto-restore saved session -> go straight to OmegaIA server selection
        Optional<SessionData> saved = authService.restoreSession();
        if (saved.isPresent()) {
            showServerOmegaView(saved.get());
        } else {
            showLoginView();
        }
        stage.show();
    }

    public void showLoginView() {
        LoginView loginView = new LoginView(primaryStage, config, authService, themeManager, this::showServerOmegaView);
        rootContainer.getChildren().setAll(loginView.getRoot());
        primaryStage.setWidth(400);
        primaryStage.setHeight(500);
        primaryStage.centerOnScreen();
    }

    public void showServerOmegaView(SessionData session) {
        ServerOmegaView serverView = new ServerOmegaView(
                primaryStage,
                config,
                session,
                gameDirectory,
                themeManager,
                integrityVerifier,
                updaterService,
                () -> {
                    authService.logout();
                    Platform.runLater(this::showLoginView);
                }
        );
        rootContainer.getChildren().setAll(serverView.getRoot());
        primaryStage.setWidth(1020);
        primaryStage.setHeight(600);
        primaryStage.centerOnScreen();
    }

    private Path resolveGameDirectory() {
        String os = System.getProperty("os.name").toLowerCase();
        String home = System.getProperty("user.home");
        if (os.contains("win")) {
            String appData = System.getenv("APPDATA");
            return Paths.get(appData != null ? appData : home, ".omegacraft");
        }
        return Paths.get(home, ".omegacraft");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
