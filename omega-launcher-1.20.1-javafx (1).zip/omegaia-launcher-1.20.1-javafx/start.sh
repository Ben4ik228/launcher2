#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=== Сборка OmegaIA Launcher (JDK 17 + JavaFX 17) ==="
mvn clean package -DskipTests
echo "Готово: target/omega-launcher-2.4.0.jar"
java -jar "target/omega-launcher-2.4.0.jar"
